import torch
import torch.nn as nn
from typing import Literal
from rxlm.transformers.ff import FeedForward, GatedFeedForward2
from rxlm.transformers.attention import MultiHeadAttention
from .attention import HybridStatefulMHA, HybridStatefulGQA, HybridStatefulMQA, HybridStatefulSQA

class StatelessDenseTransformerLayer(nn.Module):
    """Stateless Attention Transformer layer with self-attention."""

    def __init__(
            self,
            embed_dim: int,
            ff_dim: int,
            self_attention: MultiHeadAttention,
            use_rms_norm: bool = True,
            ff_activation: nn.Module = nn.SiLU(),
            ff_dropout: float = 0.0,
            ff_bias: bool = False,
            use_gated: bool = True,
            *args,
            **kwargs,
    ):
        super(StatelessDenseTransformerLayer, self).__init__(*args, **kwargs)

        self.attention = self_attention

        if use_gated:
            self.ff = GatedFeedForward2(embed_dim, ff_dim, ff_activation, dropout=ff_dropout, use_bias=ff_bias)
        else:
            self.ff = FeedForward(embed_dim, ff_dim, ff_activation, dropout=ff_dropout, use_bias=ff_bias)

        if use_rms_norm:
            self.norm1 = nn.RMSNorm(embed_dim)
            self.norm2 = nn.RMSNorm(embed_dim)
        else:
            self.norm1 = nn.LayerNorm(embed_dim)
            self.norm2 = nn.LayerNorm(embed_dim)

    def update_max_len(self, max_seq_len: int):
        if self.attention.rope is not None:
            self.attention.rope.update_max_len(max_seq_len)

    def forward(self, x: torch.Tensor, mask: torch.Tensor = None, use_self_attn_cache: bool = False, current_positions: torch.Tensor = None) -> torch.Tensor:
        # First step, self-attention
        residual = x

        x = self.norm1(x)
        x = self.attention(x, x, x, mask=mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions)

        x = residual + x
        # Second step, Feed Forward network
        residual = x
        x = self.norm2(x)
        x = self.ff(x)
        x = residual + x
        return x


class HybridStatefulDenseTransformerLayer(StatelessDenseTransformerLayer):
    """Hybrid Attention Transformer layer with combined self and cross attention."""

    def __init__(
            self,
            embed_dim: int,
            ff_dim: int,
            self_attention: MultiHeadAttention,
            use_rms_norm: bool = True,
            ff_activation: nn.Module = nn.SiLU(),
            ff_dropout: float = 0.0,
            ff_bias: bool = False,
            use_gated: bool = True,
            use_memory_gate: bool = False,
            memory_gate_type: Literal['linear', 'elementwise'] = 'linear',
            stm_size: int = 0,
            *args,
            **kwargs
    ):
        super(HybridStatefulDenseTransformerLayer, self).__init__(
            embed_dim, ff_dim, self_attention, use_rms_norm,
            ff_activation, ff_dropout, ff_bias, use_gated,
            *args, **kwargs
        )

        assert (
            isinstance(self.attention, HybridStatefulMHA)
            or isinstance(self.attention, HybridStatefulGQA)
            or isinstance(self.attention, HybridStatefulMQA)
            or isinstance(self.attention, HybridStatefulSQA)
        ), 'Hybrid Stateful Layer should use Hybrid Stateful Attention layers'

        self.use_memory_gate = use_memory_gate
        self.memory_gate_type = memory_gate_type

        if self.use_memory_gate and stm_size > 0:
            if self.memory_gate_type == 'linear':
                self.memory_gate = nn.Linear(embed_dim, 1, bias=False)
            else:
                self.memory_gate = nn.Parameter(torch.ones(1, stm_size))

    def get_kv_cache(self, stm_size: int = 0, seq_len: int = None):
        key = self.attention.key_cache
        value = self.attention.value_cache
        mask = self.attention.mask_cache

        if key is not None:
            if seq_len is not None:
                key = key[:, :, stm_size:stm_size+seq_len, :]
                value = value[:, :, stm_size:stm_size+seq_len, :]
                mask = mask[:, :, :seq_len, stm_size:stm_size+seq_len]
            else:
                key = key[:, :, stm_size:, :]
                value = value[:, :, stm_size:, :]
                mask = mask[:, :, :, stm_size:]

        return key, value, mask

    def _apply_memory_gate(self, stm: torch.Tensor):
        if self.memory_gate_type == 'linear':
            gate_logits = self.memory_gate(stm)
        else:
            gate_logits = (stm.mean(dim=-1) * self.memory_gate).unsqueeze(-1)

        gate = torch.sigmoid(gate_logits)

        return gate * stm

    def _stateful_attention(
            self, x: torch.Tensor, stm: torch.Tensor = None, mask: torch.Tensor = None,
            use_self_attn_cache: bool = False, current_positions: torch.Tensor = None
    ):
        stm_size = stm.size(1)
        stm_mask = torch.ones(x.size(0), 1, x.size(1), stm_size, device=stm.device, dtype=torch.bool)
        kv_mask = torch.cat([stm_mask, mask], dim=-1)

        if self.use_memory_gate:
            stm = self._apply_memory_gate(stm)

        stm = self.norm1(stm)
        x = self.norm1(x)

        kv = torch.cat([stm, x], dim=1)

        return self.attention(
            x, kv, kv,
            mask=kv_mask, use_self_attn_cache=use_self_attn_cache,
            current_positions=current_positions, stm_size=stm_size
        )

    def forward(
            self, x: torch.Tensor, stm: torch.Tensor = None, mask: torch.Tensor = None,
            use_self_attn_cache: bool = False, current_positions: torch.Tensor = None
    ) -> torch.Tensor:
        # First step, self-attention
        residual = x

        if stm is not None:
            if x.size(1) == 1 and use_self_attn_cache:
                x = self.norm1(x)
                x = self.attention(x, x, x, mask=mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions, stm_size=stm.size(1))
            else:
                x = self._stateful_attention(x, stm, mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions)
        else:
            x = self.norm1(x)
            x = self.attention(x, x, x, mask=mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions, stm_size=0)

        x = residual + x
        # Second step, Feed Forward network
        residual = x
        x = self.norm2(x)
        x = self.ff(x)
        x = residual + x
        return x

