import torch
import torch.nn as nn
from rxlm.transformers.mask import create_causal_mask
from rxlm.transformers.llm_models import ClassicTransformerBase
from rxlm.memory.stm import ShortTermMemory
from .layers import HybridStatefulDenseTransformerLayer

class HybridStatefulDecoder(ClassicTransformerBase):
    def __init__(
            self,
            stm: ShortTermMemory,
            embed_dim: int,
            vocab_size: int,
            tie_embeddings: bool = False,
            head_norm_type: str = 'rms_norm',
            num_stateful_layers: int = 0,
            head_bias: bool = False,
            training_cache: bool = False,
            *args,
            **kwargs
    ):
        super(HybridStatefulDecoder, self).__init__(*args, **kwargs)

        self.stm = stm

        # When using tied embeddings, we don't create a head at all
        # In forward pass, we'll compute logits as x @ embedding.weight.T (no bias)
        self.tie_embeddings = tie_embeddings
        if not tie_embeddings:
            self.head = nn.Linear(embed_dim, vocab_size, bias=head_bias)
        else:
            self.head = None

        if head_norm_type == 'rms_norm':
            self.head_norm = nn.RMSNorm(embed_dim)
        elif head_norm_type == 'layer_norm':
            self.head_norm = nn.LayerNorm(embed_dim)
        else:
            raise ValueError(f"head_norm_type must be 'layer_norm' or 'rms_norm', got '{head_norm_type}'")

        self.num_stateful_layers = num_stateful_layers
        self.training_cache = training_cache

    def reset_self_attn_cache(self):
        for i in range(self.num_layers):
            self.layers[i].attention.reset_inner_cache()

    def get_stateful_kv_cache(self, stm_size: int = 0, seq_len: int = None):
        key_cache = []
        value_cache = []
        mask_cache = []

        for i in range(self.num_layers):
            if isinstance(self.layers[i], HybridStatefulDenseTransformerLayer):
                key, value, mask = self.layers[i].get_kv_cache(stm_size, seq_len=seq_len)
                key_cache.append(key)
                value_cache.append(value)
                mask_cache.append(mask)

        return key_cache, value_cache, mask_cache

    def process_head(self, x: torch.Tensor) -> torch.Tensor:
        normalized = self.head_norm(x)

        if self.tie_embeddings:
            return torch.matmul(normalized, self.embedding.weight.T)
        else:
            return self.head(normalized)

    def forward(self, x: torch.Tensor, attention_mask: torch.Tensor = None, use_self_attn_cache: bool = False, current_positions: torch.Tensor = None, skip_stm: bool = False):
        x = super().forward(x)  # apply embeddings
        seq_len = x.size(1)
        if seq_len != 1:
            mask = create_causal_mask(seq_len, device=x.device).expand(x.size(0), -1, -1, -1).clone().to(dtype=torch.bool)
            if attention_mask is not None:
                mask &= attention_mask.unsqueeze(1).unsqueeze(1).bool()
        elif attention_mask is not None:
            mask = attention_mask.unsqueeze(1).unsqueeze(1).bool()
        else:
            mask = None

        batch_size, seq_len, embed_dim = x.shape
        hidden_states = torch.empty(
            self.num_stateful_layers, batch_size, seq_len, embed_dim,
            device=x.device, dtype=x.dtype
        )

        stateful_layer_idx = 0

        # Process layers
        for i in range(self.num_layers):
            if isinstance(self.layers[i], HybridStatefulDenseTransformerLayer):
                layer_stm = self.stm(stateful_layer_idx) if not skip_stm else None
                x = self.layers[i](x, stm=layer_stm, mask=mask, use_self_attn_cache=use_self_attn_cache or self.training_cache, current_positions=current_positions)
                hidden_states[stateful_layer_idx] = x
                stateful_layer_idx += 1
            else:
                x = self.layers[i](x, mask=mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions)

        return self.process_head(x), hidden_states

