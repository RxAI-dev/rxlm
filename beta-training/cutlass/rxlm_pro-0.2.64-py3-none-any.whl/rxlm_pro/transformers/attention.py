import torch
import torch.nn as nn
from rxlm.transformers.attention import MultiHeadAttention, GroupedQueryAttention, MultiQueryAttention, SparseQueryAttention

def init_cache(
        layer: MultiHeadAttention, b: int, t: int, kv_len: int, k: torch.Tensor, v: torch.Tensor,
        mask: torch.Tensor = None, stm_size: int = 0
):
    layer.key_cache = torch.zeros(b, k.size(1), stm_size + layer.rope.max_seq_len, k.size(-1), device=k.device,
                                 dtype=k.dtype)
    layer.value_cache = torch.zeros_like(layer.key_cache).to(v.device, dtype=v.dtype)
    layer.mask_cache = torch.zeros(b, 1, layer.rope.max_seq_len, stm_size + layer.rope.max_seq_len, device=mask.device,
                                  dtype=mask.dtype)

    layer.key_cache[:, :, :kv_len, :] = k
    layer.value_cache[:, :, :kv_len, :] = v
    layer.mask_cache[:, :, :t, :kv_len] = mask
    layer.kv_len = kv_len

def update_cache(
        layer: MultiHeadAttention, b: int, new_k: torch.Tensor, new_v: torch.Tensor,
        mask: torch.Tensor = None, stm_size: int = 0, current_positions: torch.Tensor = None
):
    batch_range = torch.arange(b, device=new_k.device)
    layer.key_cache[batch_range, :, stm_size + current_positions, :] = new_k.squeeze(-2)
    layer.value_cache[batch_range, :, stm_size + current_positions, :] = new_v.squeeze(-2)
    layer.mask_cache[batch_range, :, current_positions, stm_size + current_positions] = mask.squeeze(-1).squeeze(-1)
    layer.kv_len += 1

    k = layer.key_cache
    v = layer.value_cache
    mask = layer.mask_cache

    return k[:, :, :layer.kv_len, :], v[:, :, :layer.kv_len, :], mask[:, :, -1, :layer.kv_len]

class HybridStatefulMHA(MultiHeadAttention):
    def __init__(
            self,
            embed_dim: int,
            num_heads: int,
            use_separate_memory_projections: bool = False,
            **kwargs,
    ):
        self.use_separate_memory_projections = use_separate_memory_projections
        super(HybridStatefulMHA, self).__init__(embed_dim, num_heads, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _init_kv(self, embed_dim: int):
        """Initialize key and value projections"""
        self.k_proj = nn.Linear(embed_dim, self.head_dim * self.num_heads, bias=self.use_bias)
        self.v_proj = nn.Linear(embed_dim, self.head_dim * self.num_heads, bias=self.use_bias)

        # KV projections for memory
        if self.use_separate_memory_projections:
            self.mk_proj = nn.Linear(embed_dim, self.head_dim * self.num_heads, bias=self.use_bias)
            self.mv_proj = nn.Linear(embed_dim, self.head_dim * self.num_heads, bias=self.use_bias)

    def _merge_hybrid_kv(self, key: torch.Tensor, value: torch.Tensor, b: int, t: int, stm_size: int = 0):
        if self.use_separate_memory_projections:
            proj_k = torch.cat([self.mk_proj(key[:, :stm_size, :]), self.k_proj(key[:, stm_size:, :])], dim=1)
            proj_v = torch.cat([self.mv_proj(value[:, :stm_size, :]), self.v_proj(value[:, stm_size:, :])], dim=1)
        else:
            proj_k = self.k_proj(key)
            proj_v = self.v_proj(value)

        k = self.split_kv_head(proj_k, b, t)
        v = self.split_kv_head(proj_v, b, t)

        return k, v

    def _forward_qkv(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, b: int, t: int, stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None, stm_size: int = 0):
        """Forward pass through query, key, and value projections, and split the results into heads"""
        q = self._split_q_head(self.q_proj(query), b, t)

        k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

        return q, k, v

    def _forward_with_hybrid_attention_cached(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        kv_len = key.size(1)
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

            q, k = self._apply_qk_norm(q, k)

            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            init_cache(self, b, t, kv_len, k, v, mask, stm_size)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=True)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, stm_size, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        return self.out_proj(attn_output)

    def _forward_with_hybrid_attention(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        q, k, v = self._forward_qkv(query, key, value, b, t, stm_size=stm_size)

        q, k = self._apply_qk_norm(q, k)

        if not self.rel_embed:
            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=stm_size>0)
        else:
            attn_output = self._calculate_attention_with_relative_embedding(q, k, v, b, t, d, mask=mask)
        return self.out_proj(attn_output)


    def forward(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None,
            use_self_attn_cache: bool = False,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        if use_self_attn_cache:
            return self._forward_with_hybrid_attention_cached(query, key, value, mask=mask, current_positions=current_positions, stm_size=stm_size)
        else:
            return self._forward_with_hybrid_attention(query, key, value, mask=mask, stm_size=stm_size)


class HybridStatefulGQA(GroupedQueryAttention):
    def __init__(
            self,
            embed_dim: int,
            num_heads: int,
            num_groups: int,
            use_separate_memory_projections: bool = False,
            **kwargs,
    ):
        self.use_separate_memory_projections = use_separate_memory_projections
        super(HybridStatefulGQA, self).__init__(embed_dim, num_heads, num_groups, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _init_kv(self, embed_dim: int):
        """Initialize key and value projections"""
        self.k_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        self.v_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        if self.use_separate_memory_projections:
            # KV projections for memory
            self.mk_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
            self.mv_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)

    def _merge_hybrid_kv(self, key: torch.Tensor, value: torch.Tensor, b: int, t: int, stm_size: int = 0):
        if self.use_separate_memory_projections:
            proj_k = torch.cat([self.mk_proj(key[:, :stm_size, :]), self.k_proj(key[:, stm_size:, :])], dim=1)
            proj_v = torch.cat([self.mv_proj(value[:, :stm_size, :]), self.v_proj(value[:, stm_size:, :])], dim=1)
        else:
            proj_k = self.k_proj(key)
            proj_v = self.v_proj(value)

        k = self.split_kv_head(proj_k, b, t)
        v = self.split_kv_head(proj_v, b, t)

        return k, v

    def _forward_qkv(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, b: int, t: int,
                     stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None, stm_size: int = 0):
        """Forward pass through query, key, and value projections, and split the results into heads"""
        q = self._split_q_head(self.q_proj(query), b, t)

        k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

        return q, k, v

    def _forward_with_hybrid_attention_cached(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        kv_len = key.size(1)
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

            q, k = self._apply_qk_norm(q, k)

            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            init_cache(self, b, t, kv_len, k, v, mask, stm_size)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=True)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, stm_size, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        return self.out_proj(attn_output)

    def _forward_with_hybrid_attention(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        q, k, v = self._forward_qkv(query, key, value, b, t)

        q, k = self._apply_qk_norm(q, k)

        if not self.rel_embed:
            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=stm_size>0)
        else:
            attn_output = self._calculate_attention_with_relative_embedding(q, k, v, b, t, d, mask=mask)
        return self.out_proj(attn_output)


    def forward(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None,
            use_self_attn_cache: bool = False,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        if use_self_attn_cache:
            return self._forward_with_hybrid_attention_cached(query, key, value, mask=mask, current_positions=current_positions, stm_size=stm_size)
        else:
            return self._forward_with_hybrid_attention(query, key, value, mask=mask, stm_size=stm_size)


class HybridStatefulMQA(MultiQueryAttention):
    def __init__(
            self,
            embed_dim: int,
            num_heads: int,
            use_separate_memory_projections: bool = False,
            **kwargs,
    ):
        self.use_separate_memory_projections = use_separate_memory_projections
        super(HybridStatefulMQA, self).__init__(embed_dim, num_heads, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _init_kv(self, embed_dim: int):
        """Initialize key and value projections"""
        self.k_proj = nn.Linear(embed_dim, self.head_dim, bias=self.use_bias)
        self.v_proj = nn.Linear(embed_dim, self.head_dim, bias=self.use_bias)
        if self.use_separate_memory_projections:
            # KV projections for memory
            self.mk_proj = nn.Linear(embed_dim, self.head_dim, bias=self.use_bias)
            self.mv_proj = nn.Linear(embed_dim, self.head_dim, bias=self.use_bias)

    def _merge_hybrid_kv(self, key: torch.Tensor, value: torch.Tensor, b: int, t: int, stm_size: int = 0):
        if self.use_separate_memory_projections:
            proj_k = torch.cat([self.mk_proj(key[:, :stm_size, :]), self.k_proj(key[:, stm_size:, :])], dim=1)
            proj_v = torch.cat([self.mv_proj(value[:, :stm_size, :]), self.v_proj(value[:, stm_size:, :])], dim=1)
        else:
            proj_k = self.k_proj(key)
            proj_v = self.v_proj(value)

        k = self.split_kv_head(proj_k, b, t)
        v = self.split_kv_head(proj_v, b, t)

        return k, v

    def _forward_qkv(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, b: int, t: int,
                     stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None, stm_size: int = 0):
        """Forward pass through query, key, and value projections, and split the results into heads"""
        q = self._split_q_head(self.q_proj(query), b, t)

        k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

        return q, k, v

    def _forward_with_hybrid_attention_cached(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        kv_len = key.size(1)
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

            q, k = self._apply_qk_norm(q, k)

            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            init_cache(self, b, t, kv_len, k, v, mask, stm_size)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=True)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, stm_size, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        return self.out_proj(attn_output)

    def _forward_with_hybrid_attention(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        q, k, v = self._forward_qkv(query, key, value, b, t)

        q, k = self._apply_qk_norm(q, k)

        if not self.rel_embed:
            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=stm_size>0)
        else:
            attn_output = self._calculate_attention_with_relative_embedding(q, k, v, b, t, d, mask=mask)
        return self.out_proj(attn_output)


    def forward(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None,
            use_self_attn_cache: bool = False,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        if use_self_attn_cache:
            return self._forward_with_hybrid_attention_cached(query, key, value, mask=mask, current_positions=current_positions, stm_size=stm_size)
        else:
            return self._forward_with_hybrid_attention(query, key, value, mask=mask, stm_size=stm_size)


class HybridStatefulSQA(SparseQueryAttention):
    def __init__(
            self,
            embed_dim: int,
            num_heads: int,
            num_groups: int,
            use_separate_memory_projections: bool = False,
            **kwargs,
    ):
        self.use_separate_memory_projections = use_separate_memory_projections
        super(HybridStatefulSQA, self).__init__(embed_dim, num_heads, num_groups, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _init_kv(self, embed_dim: int):
        """Initialize key and value projections"""
        self.k_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        self.v_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        if self.use_separate_memory_projections:
            # KV projections for memory
            self.mk_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)
            self.mv_proj = nn.Linear(embed_dim, self.head_dim * self.num_groups, bias=self.use_bias)

    def _merge_hybrid_kv(self, key: torch.Tensor, value: torch.Tensor, b: int, t: int, stm_size: int = 0):
        if self.use_separate_memory_projections:
            proj_k = torch.cat([self.mk_proj(key[:, :stm_size, :]), self.k_proj(key[:, stm_size:, :])], dim=1)
            proj_v = torch.cat([self.mv_proj(value[:, :stm_size, :]), self.v_proj(value[:, stm_size:, :])], dim=1)
        else:
            proj_k = self.k_proj(key)
            proj_v = self.v_proj(value)

        k = self.split_kv_head(proj_k, b, t)
        v = self.split_kv_head(proj_v, b, t)

        return k, v

    def _forward_qkv(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, b: int, t: int,
                     stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None, stm_size: int = 0):
        """Forward pass through query, key, and value projections, and split the results into heads"""
        q = self._split_q_head(self.q_proj(query), b, t)

        k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

        return q, k, v

    def _forward_with_hybrid_attention_cached(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        kv_len = key.size(1)
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k, v = self._merge_hybrid_kv(key, value, b, t, stm_size=stm_size)

            q, k = self._apply_qk_norm(q, k)

            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            init_cache(self, b, t, kv_len, k, v, mask, stm_size)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=True)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, stm_size, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        return self.out_proj(attn_output)

    def _forward_with_hybrid_attention(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_size: int = 0,
    ):
        b, t, d = query.size()
        q, k, v = self._forward_qkv(query, key, value, b, t)

        q, k = self._apply_qk_norm(q, k)

        if not self.rel_embed:
            q, k_pos = self._apply_rope(q, k[:, :, stm_size:, :])
            k[:, :, stm_size:, :] = k_pos

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=stm_size>0)
        else:
            attn_output = self._calculate_attention_with_relative_embedding(q, k, v, b, t, d, mask=mask)
        return self.out_proj(attn_output)


    def forward(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            stm_kv_cache: tuple[torch.Tensor, torch.Tensor] = None,
            use_self_attn_cache: bool = False,
            current_positions: torch.Tensor = None,
            stm_size: int = 0,
    ):
        if use_self_attn_cache:
            return self._forward_with_hybrid_attention_cached(query, key, value, mask=mask, current_positions=current_positions, stm_size=stm_size)
        else:
            return self._forward_with_hybrid_attention(query, key, value, mask=mask, stm_size=stm_size)


class MemoryMHA(MultiHeadAttention):
    def __init__(self, kv_input_dim: int, *args, **kwargs):
        self.kv_input_dim = kv_input_dim
        super(MemoryMHA, self).__init__(*args, **kwargs)

    def _init_kv(self, embed_dim: int):
        self.k_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_heads, bias=self.use_bias)
        self.v_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_heads, bias=self.use_bias)


class MemoryGQA(GroupedQueryAttention):
    def __init__(self, kv_input_dim: int, *args, **kwargs):
        self.kv_input_dim = kv_input_dim
        super(MemoryGQA, self).__init__(*args, **kwargs)

    def _init_kv(self, embed_dim: int):
        self.k_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        self.v_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_groups, bias=self.use_bias)


class MemoryMQA(MultiQueryAttention):
    def __init__(self, kv_input_dim: int, *args, **kwargs):
        self.kv_input_dim = kv_input_dim
        super(MemoryMQA, self).__init__(*args, **kwargs)

    def _init_kv(self, embed_dim: int):
        self.k_proj = nn.Linear(self.kv_input_dim, self.head_dim, bias=self.use_bias)
        self.v_proj = nn.Linear(self.kv_input_dim, self.head_dim, bias=self.use_bias)


class MemorySQA(SparseQueryAttention):
    def __init__(self, kv_input_dim: int, *args, **kwargs):
        self.kv_input_dim = kv_input_dim
        super(MemorySQA, self).__init__(*args, **kwargs)

    def _init_kv(self, embed_dim: int):
        self.k_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_groups, bias=self.use_bias)
        self.v_proj = nn.Linear(self.kv_input_dim, self.head_dim * self.num_groups, bias=self.use_bias)


class StatelessMHA(MultiHeadAttention):
    def __init__(
            self,
            *args,
            **kwargs,
    ):
        super(StatelessMHA, self).__init__(*args, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _forward_with_inner_cache(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
    ):
        b, t, d = query.size()
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k = self.split_kv_head(self.k_proj(key), b, t)
            v = self.split_kv_head(self.v_proj(value), b, t)

            q, k = self._apply_qk_norm(q, k)

            q, k = self._apply_rope(q, k)

            init_cache(self, b, t, t, k, v, mask, 0)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=False)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, 0, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        if self.use_gated_attention:
            gate_logits = self.gate_proj(query)
            gate = self.gate_activation(gate_logits)
            attn_output = attn_output * gate

        return self.out_proj(attn_output)


class StatelessGQA(GroupedQueryAttention):
    def __init__(
            self,
            *args,
            **kwargs,
    ):
        super(StatelessGQA, self).__init__(*args, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _forward_with_inner_cache(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
    ):
        b, t, d = query.size()
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k = self.split_kv_head(self.k_proj(key), b, t)
            v = self.split_kv_head(self.v_proj(value), b, t)

            q, k = self._apply_qk_norm(q, k)

            q, k = self._apply_rope(q, k)

            init_cache(self, b, t, t, k, v, mask, 0)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=False)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, 0, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        if self.use_gated_attention:
            gate_logits = self.gate_proj(query)
            gate = self.gate_activation(gate_logits)
            attn_output = attn_output * gate

        return self.out_proj(attn_output)


class StatelessMQA(MultiQueryAttention):
    def __init__(
            self,
            *args,
            **kwargs,
    ):
        super(StatelessMQA, self).__init__(*args, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _forward_with_inner_cache(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
    ):
        b, t, d = query.size()
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k = self.split_kv_head(self.k_proj(key), b, t)
            v = self.split_kv_head(self.v_proj(value), b, t)

            q, k = self._apply_qk_norm(q, k)

            q, k = self._apply_rope(q, k)

            init_cache(self, b, t, t, k, v, mask, 0)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=False)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, 0, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        if self.use_gated_attention:
            gate_logits = self.gate_proj(query)
            gate = self.gate_activation(gate_logits)
            attn_output = attn_output * gate

        return self.out_proj(attn_output)


class StatelessSQA(SparseQueryAttention):
    def __init__(
            self,
            *args,
            **kwargs,
    ):
        super(StatelessSQA, self).__init__(*args, **kwargs)
        self.kv_len = 0

    def reset_inner_cache(self):
        super().reset_inner_cache()
        self.kv_len = 0

    def _forward_with_inner_cache(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            mask: torch.Tensor = None,
            current_positions: torch.Tensor = None,
    ):
        b, t, d = query.size()
        q = self._split_q_head(self.q_proj(query), b, t)

        if self.key_cache is None and self.value_cache is None:
            k = self.split_kv_head(self.k_proj(key), b, t)
            v = self.split_kv_head(self.v_proj(value), b, t)

            q, k = self._apply_qk_norm(q, k)

            q, k = self._apply_rope(q, k)

            init_cache(self, b, t, t, k, v, mask, 0)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=mask, generate_mode=False)
        else:
            new_k = self.split_kv_head(self.k_proj(key), b, t)
            new_v = self.split_kv_head(self.v_proj(value), b, t)

            q, new_k = self._apply_qk_norm(q, new_k)

            q, new_k = self.rope.forward_on(q, new_k, current_positions)

            k, v, mask = update_cache(self, b, new_k, new_v, mask, 0, current_positions)

            attn_output = self._calculate_attention(q, k, v, b, t, d, mask=None, generate_mode=True)

        if self.use_gated_attention:
            gate_logits = self.gate_proj(query)
            gate = self.gate_activation(gate_logits)
            attn_output = attn_output * gate

        return self.out_proj(attn_output)