import torch
import torch.nn as nn
from typing import TypedDict, Literal, Union, Iterator
from huggingface_hub import PyTorchModelHubMixin
from transformers import PreTrainedTokenizer, PreTrainedTokenizerFast

from rxlm.transformers.positional import RotaryPositionalEmbedding
from rxlm.utils import get_model_size
from rxlm.transformers.attention import MultiHeadAttention, GroupedQueryAttention
from rxlm.memory.stm import ShortTermMemory
from rxlm.memory.gate import ResidualGate, ResidualGateType, SlotStatusType
from rxlm.training.tokenizer import decode_post_process
from rxlm.transformers.sampler import sample
from ..transformers.attention import HybridStatefulGQA, MemoryMHA, MemoryGQA, StatelessGQA
from ..transformers.layers import StatelessDenseTransformerLayer, HybridStatefulDenseTransformerLayer
from ..transformers.models import HybridStatefulDecoder
from ..memory.attention import RcGroupedStmMemoryAttention, RcGatedStmMemoryAttention, RcSelfStmMemoryAttention, RcSimpleStmMemoryAttention

from transformers import Qwen3ForCausalLM

class RxQwenDenseDecoderConfig(TypedDict):
    num_layers: int
    layer_types: list[Literal['stateless', 'stateful']]
    vocab_size: int
    embed_dim: int
    ff_dim: int
    att_heads: int
    kv_heads: int
    head_dim: int
    seq_len: int
    stm_size: int
    use_flash_attention: bool
    ff_dropout: float
    att_dropout: float
    rope_base: int
    tie_embeddings: bool
    padding_idx: int
    use_separate_memory_projections: bool
    use_memory_gate: bool
    memory_gate_type: Literal['linear', 'elementwise']
    stm_batch_size: int


class RxQwenDenseDecoder(nn.Module, PyTorchModelHubMixin, pipeline_tag="text-generation", license="apache-2.0"):
    """
    Reactive Qwen Dense Decoder model - for fine-tuning from Qwen3 dense models
    """

    def __init__(
            self,
            num_layers: int,
            layer_types: list[Literal['stateless', 'stateful']],
            vocab_size: int,
            embed_dim: int,
            ff_dim: int,
            att_heads: int,
            kv_heads: int,
            head_dim: int,
            seq_len: int,
            stm_size: int,
            use_flash_attention: bool = True,
            ff_dropout: float = 0.0,
            att_dropout: float = 0.0,
            rope_base: int = 1_000_000,
            tie_embeddings: bool = True,
            padding_idx: int = 0,
            skip_stm: bool = False,
            use_separate_memory_projections: bool = False,
            use_memory_gate: bool = False,
            memory_gate_type: Literal['linear', 'elementwise'] = 'linear',
            stm_batch_size: int = 1,
            training_cache: bool = False,
            **kwargs
    ):
        super(RxQwenDenseDecoder, self).__init__(**kwargs)

        num_stateful_layers = sum([1 for layer_type in layer_types if layer_type == 'stateful'])

        embedding = nn.Embedding(vocab_size, embed_dim, padding_idx)
        rope = RotaryPositionalEmbedding(head_dim, seq_len, rope_base)
        stm = ShortTermMemory(num_stateful_layers, embed_dim, stm_size)
        self.skip_stm = skip_stm

        if stm_batch_size == 1:
            stm.single_memory()
        else:
            stm.batched_memory(stm_batch_size)

        assert num_layers == len(layer_types), 'Incorrect number of layers configuration'

        def init_layer(layer_type: Literal['stateless', 'stateful']):
            if layer_type == 'stateless':
                return StatelessDenseTransformerLayer(
                    embed_dim,
                    ff_dim,
                    StatelessGQA(
                        embed_dim,
                        att_heads,
                        kv_heads,
                        head_dim=head_dim,
                        dropout=att_dropout,
                        rope=rope,
                        max_seq_len=seq_len,
                        use_flash_attention=use_flash_attention,
                        is_causal=True,
                        use_bias=False,
                        use_output_bias=False,
                        use_gated_attention=False,
                        use_qk_norm=True,
                    ),
                    ff_dropout=ff_dropout,
                    ff_bias=False,
                    ff_activation=nn.SiLU(),
                    use_gated=True
                )
            else:
                return HybridStatefulDenseTransformerLayer(
                    embed_dim,
                    ff_dim,
                    HybridStatefulGQA(
                        embed_dim,
                        att_heads,
                        kv_heads,
                        head_dim=head_dim,
                        dropout=att_dropout,
                        rope=rope,
                        max_seq_len=seq_len,
                        use_flash_attention=use_flash_attention,
                        is_causal=True,
                        use_bias=False,
                        use_output_bias=False,
                        use_gated_attention=False,
                        use_qk_norm=True,
                        use_separate_memory_projections=use_separate_memory_projections,
                    ),
                    ff_dropout=ff_dropout,
                    ff_bias=False,
                    ff_activation=nn.SiLU(),
                    use_gated=True,
                    use_memory_gate=use_memory_gate,
                    memory_gate_type=memory_gate_type,
                    stm_size=stm_size,
                )

        self.model = HybridStatefulDecoder(
            stm,
            embed_dim,
            vocab_size,
            tie_embeddings=tie_embeddings,
            embedding=embedding,
            layers=nn.ModuleList([init_layer(layer_type) for layer_type in layer_types]),
            use_flash_attention=use_flash_attention,
            head_bias=False,
            num_stateful_layers=num_stateful_layers,
            training_cache=training_cache,
        )

    def params_count(self):
        return get_model_size(self.model)

    def reset_self_attn_cache(self):
        return self.model.reset_self_attn_cache()

    def get_stateful_kv_cache(self, stm_size: int = 0, seq_len: int = None):
        return self.model.get_stateful_kv_cache(stm_size, seq_len=seq_len)

    def load_shared_memory(self, stm: ShortTermMemory):
        self.model.stm = stm

    def update_max_len(self, max_seq_len: int):
        self.model.update_max_len(max_seq_len)

    def reset_memory(self, init_type: str = None):
        self.model.stm.reset(init_type)

    def clone_reset_memory(self):
        self.model.stm.clone_detach_reset()

    def forward(self, x: torch.Tensor, attention_mask: torch.Tensor = None, use_self_attn_cache: bool = False, current_positions: torch.Tensor = None, skip_stm: bool = False):
        if self.skip_stm:
            skip_stm = self.skip_stm

        return self.model(x, attention_mask=attention_mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions, skip_stm=skip_stm)


class RxQwenMemoryAttentionConfig(TypedDict):
    variant: Literal['simple', 'self', 'self-interlayer', 'grouped-self-interlayer']
    num_layers: int
    embed_dim: int
    kv_input_dim: int
    att_heads: int
    head_dim: int
    seq_len: int
    stm_size: int
    num_groups: int
    use_flash_attention: bool
    att_dropout: float
    kv_heads: int
    use_gqa: bool
    interlayer_att_dropout: float
    interlayer_att_heads: int
    interlayer_kv_heads: int
    use_interlayer_gqa: bool
    residual_gate_init: float
    residual_gate_type: ResidualGateType
    rope_base: int
    use_qk_norm: bool
    interlayer_qk_norm: bool


class RxQwenMemoryAttention(nn.Module, PyTorchModelHubMixin, license="other"):
    """Reactive Qwen Memory Attention model with grouped/gated self/interlayer STM attention"""

    def __init__(
            self,
            variant: Literal['simple', 'self', 'self-interlayer', 'grouped-self-interlayer'],
            num_layers: int,
            embed_dim: int,
            kv_input_dim: int,
            att_heads: int,
            head_dim: int,
            seq_len: int,
            stm_size: int,
            num_groups: int = 1,
            use_flash_attention: bool = False,
            att_dropout: float = 0.0,
            kv_heads: int = None,
            use_gqa: bool = False,
            interlayer_att_dropout: float = 0.0,
            interlayer_att_heads: int = 1,
            interlayer_kv_heads: int = 1,
            use_interlayer_gqa: bool = False,
            residual_gate_init: float = 3.0,
            residual_gate_type: ResidualGateType = 'elementwise',
            rope_base: int = 1_000_000,
            use_qk_norm: bool = True,
            interlayer_qk_norm: bool = True,
            **kwargs,
    ):
        super(RxQwenMemoryAttention, self).__init__(**kwargs)

        rope = RotaryPositionalEmbedding(head_dim, seq_len, rope_base)
        stm = ShortTermMemory(num_layers, embed_dim, stm_size)

        def attn_init():
            if use_gqa:
                return MemoryGQA(
                    kv_input_dim,
                    embed_dim,
                    att_heads,
                    kv_heads,
                    head_dim=head_dim,
                    dropout=att_dropout,
                    rope=rope,
                    max_seq_len=seq_len,
                    use_flash_attention=use_flash_attention,
                    is_causal=False,
                    use_bias=False,
                    use_output_bias=False,
                    use_gated_attention=False,
                    use_qk_norm=use_qk_norm,
                    rope_only_for_keys=True,
                )
            else:
                return MemoryMHA(
                    kv_input_dim,
                    embed_dim,
                    att_heads,
                    head_dim=head_dim,
                    dropout=att_dropout,
                    rope=rope,
                    max_seq_len=seq_len,
                    use_flash_attention=use_flash_attention,
                    is_causal=False,
                    use_bias=False,
                    use_output_bias=False,
                    use_gated_attention=False,
                    use_qk_norm=use_qk_norm,
                    rope_only_for_keys=True,
                )

        memory_norm_layers = nn.ModuleList([nn.RMSNorm(embed_dim) for _ in range(num_layers)])
        memory_input_norm_layers = nn.ModuleList(nn.RMSNorm(kv_input_dim) for _ in range(num_layers))
        attention_layers = nn.ModuleList([attn_init() for _ in range(num_layers)])
        residual_gates = nn.ModuleList([
            ResidualGate(
                stm_size, embed_dim,
                use_gate=True, gate_type=residual_gate_type,
                per_slot_gate=True, init_gate=residual_gate_init,
                use_tanh_gate=False, slot_status_type='mean',
            ) for _ in range(num_layers)
        ])

        def interlayer_attn_init():
            if use_interlayer_gqa:
                return GroupedQueryAttention(
                    embed_dim,
                    interlayer_att_heads,
                    interlayer_kv_heads,
                    head_dim=head_dim,
                    dropout=interlayer_att_dropout,
                    rope=None,
                    max_seq_len=seq_len,
                    use_flash_attention=use_flash_attention,
                    is_causal=False,
                    use_bias=False,
                    use_output_bias=False,
                    use_gated_attention=False,
                    use_qk_norm=interlayer_qk_norm,
                )
            else:
                return MultiHeadAttention(
                    embed_dim,
                    interlayer_att_heads,
                    head_dim=head_dim,
                    dropout=interlayer_att_dropout,
                    rope=None,
                    max_seq_len=seq_len,
                    use_flash_attention=use_flash_attention,
                    is_causal=False,
                    use_bias=False,
                    use_output_bias=False,
                    use_gated_attention=False,
                    use_qk_norm=interlayer_qk_norm,
                )

        mean_attention_layers = nn.ModuleList([interlayer_attn_init() for _ in range(num_layers)])

        mean_stm_norm = nn.RMSNorm(embed_dim)

        mean_memory_norm_layers = nn.ModuleList([nn.RMSNorm(embed_dim) for _ in range(num_layers)])

        mean_residual_gates = nn.ModuleList([
            ResidualGate(
                stm_size, embed_dim,
                use_gate=True, gate_type=residual_gate_type,
                per_slot_gate=True, init_gate=residual_gate_init,
                use_tanh_gate=False, slot_status_type='mean',
            ) for _ in range(num_layers)
        ])

        interlayer_gates = nn.ModuleList([
            ResidualGate(
                stm_size, embed_dim,
                use_gate=True, gate_type=residual_gate_type,
                per_slot_gate=True, init_gate=residual_gate_init,
                use_tanh_gate=False, slot_status_type='mean',
            ) for _ in range(num_layers)
        ])

        if variant == 'simple':
            self.model = RcSimpleStmMemoryAttention(
                stm, attention_layers, memory_norm_layers, memory_input_norm_layers, residual_gates,
            )
        elif variant == 'self':
            self.model = RcSelfStmMemoryAttention(
                stm, attention_layers, memory_norm_layers, memory_input_norm_layers, residual_gates,
                self_attention_layers=mean_attention_layers,
                self_memory_norm_layers=mean_memory_norm_layers,
                self_residual_gate_layers=mean_residual_gates,
            )
        elif variant == 'self-interlayer':
            self.model = RcGatedStmMemoryAttention(
                stm, attention_layers, memory_norm_layers, memory_input_norm_layers, residual_gates,
                mean_attention_layers, mean_memory_norm_layers, mean_residual_gates, interlayer_gates, mean_stm_norm,
            )
        elif variant == 'grouped-self-interlayer':
            self.model = RcGroupedStmMemoryAttention(
                num_groups, stm, attention_layers, memory_norm_layers, memory_input_norm_layers, residual_gates,
                mean_attention_layers, mean_memory_norm_layers, mean_residual_gates, interlayer_gates, mean_stm_norm,
            )

    def freeze(self):
        for param in self.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.parameters():
            param.requires_grad = True

    def load_shared_memory(self, stm: ShortTermMemory):
        self.model.stm = stm

    def update_max_len(self, max_seq_len: int):
        self.model.update_max_len(max_seq_len)

    def reset_memory(self, init_type: str = None):
        self.model.stm.reset(init_type)

    def clone_reset_memory(self):
        self.model.stm.clone_detach_reset()

    def forward(self, keys: list[torch.Tensor], values: list[torch.Tensor], attention_mask: list[torch.Tensor] = None) -> torch.Tensor:
        return self.model(keys, values, attention_mask=attention_mask)


def load_qwen3_dense_weights(model_path: str, rxq_decoder: RxQwenDenseDecoder, token: str = None):
    qwen = Qwen3ForCausalLM.from_pretrained(model_path, token=token)

    assert len(qwen.model.layers) == rxq_decoder.model.num_layers, 'Loaded Qwen3 model should have the same number of layers as Reactive Qwen'

    # 1. Load embedding weights
    rxq_decoder.model.embedding.load_state_dict(qwen.model.embed_tokens.state_dict())

    # 2. Load weights for each layer
    for qwen_layer, rxq_layer in zip(qwen.model.layers, rxq_decoder.model.layers):
        # a) Norm layers
        rxq_layer.norm1.load_state_dict(qwen_layer.input_layernorm.state_dict())
        rxq_layer.norm2.load_state_dict(qwen_layer.post_attention_layernorm.state_dict())
        # b) Attention layer
        rxq_layer.attention.q_proj.load_state_dict(qwen_layer.self_attn.q_proj.state_dict())
        rxq_layer.attention.k_proj.load_state_dict(qwen_layer.self_attn.k_proj.state_dict())
        rxq_layer.attention.v_proj.load_state_dict(qwen_layer.self_attn.v_proj.state_dict())
        rxq_layer.attention.out_proj.load_state_dict(qwen_layer.self_attn.o_proj.state_dict())
        rxq_layer.attention.q_norm.load_state_dict(qwen_layer.self_attn.q_norm.state_dict())
        rxq_layer.attention.k_norm.load_state_dict(qwen_layer.self_attn.k_norm.state_dict())
        # c) Feed Forward layer
        rxq_layer.ff.down_proj.load_state_dict(qwen_layer.mlp.down_proj.state_dict())
        rxq_layer.ff.up_proj.load_state_dict(qwen_layer.mlp.up_proj.state_dict())
        rxq_layer.ff.gate_proj.load_state_dict(qwen_layer.mlp.gate_proj.state_dict())

    # 3. Load head weights
    rxq_decoder.model.head_norm.load_state_dict(qwen.model.norm.state_dict())
    if not rxq_decoder.model.tie_embeddings:
        rxq_decoder.model.head.load_state_dict(qwen.lm_head.state_dict())

    print('Successfully loaded Qwen3 model weights')


class RxQwenDenseTokenizerConfig(TypedDict):
    bos_token_id: int
    eos_token_id: int
    answer_token_id: int
    query_token_id: int
    pad_token_id: int
    think_token_id: int
    tool_call_token_id: int
    tool_use_token_id: int
    internal_token_id: int


class RxQwenDense(nn.Module, PyTorchModelHubMixin, pipeline_tag="text-generation", license="apache-2.0"):
    def __init__(
            self,
            decoder_config: RxQwenDenseDecoderConfig,
            memory_attention_config: RxQwenMemoryAttentionConfig,
            tokenizer_config: RxQwenDenseTokenizerConfig,
            tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
            system_prompt_title: str = 'SYSTEM INSTRUCTIONS',
            **kwargs
    ):
        super(RxQwenDense, self).__init__(**kwargs)
        self.decoder_config = decoder_config
        self.memory_attention_config = memory_attention_config

        self.decoder = RxQwenDenseDecoder(**decoder_config)
        self.memory_attention = RxQwenMemoryAttention(**memory_attention_config)

        self.batch_size = 1
        self.system_prompt_title = system_prompt_title

        self.bos_token_id = tokenizer_config['bos_token_id']
        self.eos_token_id = tokenizer_config['eos_token_id']
        self.pad_token_id = tokenizer_config['pad_token_id']
        self.query_token_id = tokenizer_config['query_token_id']
        self.answer_token_id = tokenizer_config['answer_token_id']
        self.think_token_id = tokenizer_config['think_token_id']
        self.tool_call_token_id = tokenizer_config['tool_call_token_id']
        self.tool_use_token_id = tokenizer_config['tool_use_token_id']
        self.internal_token_id = tokenizer_config['internal_token_id']
        self.tokenizer = tokenizer

        if self.tokenizer is not None:
            self.bos_token, self.query_token, self.answer_token, self.eos_token = self.tokenizer.convert_ids_to_tokens(
                [self.bos_token_id, self.query_token_id, self.answer_token_id, self.eos_token_id]
            )

            self.think_token, self.tool_call_token, self.tool_use_token, self.internal_token = self.tokenizer.convert_ids_to_tokens(
                [self.think_token_id, self.tool_call_token_id, self.tool_use_token_id, self.internal_token_id]
            )

        else:
            self.bos_token, self.query_token, self.answer_token, self.eos_token = None, None, None, None
            self.think_token, self.tool_call_token, self.tool_use_token, self.internal_token = None, None, None, None

    def forward(
            self,
            input_ids: torch.Tensor,
            attention_mask: torch.Tensor = None,
            use_self_attn_cache: bool = False,
            current_positions: torch.Tensor = None
    ) -> torch.Tensor:
        output, _ = self.decoder(input_ids, attention_mask=attention_mask, use_self_attn_cache=use_self_attn_cache, current_positions=current_positions)
        return output

    def set_tokenizer(self, tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast]):
        self.tokenizer = tokenizer
        self.bos_token, self.query_token, self.answer_token, self.eos_token = self.tokenizer.convert_ids_to_tokens(
            [self.bos_token_id, self.query_token_id, self.answer_token_id, self.eos_token_id]
        )
        self.think_token, self.tool_call_token, self.tool_use_token, self.internal_token = self.tokenizer.convert_ids_to_tokens(
            [self.think_token_id, self.tool_call_token_id, self.tool_use_token_id, self.internal_token_id]
        )

    def load_pretrained_weights(self, decoder: RxQwenDenseDecoder, memory_attention: RxQwenMemoryAttention):
        self.decoder.load_state_dict(decoder.state_dict(), assign=True)
        self.memory_attention.load_state_dict(memory_attention.state_dict(), assign=True)

    def share_components(self):
        # 1. Load shared STM from memory attention to decoder
        self.decoder.load_shared_memory(self.memory_attention.model.stm)
        # 2. Ensure correct initial memory shape
        self.set_batch_mode(self.batch_size != 1, self.batch_size)

    def set_batch_mode(self, use_batch_mode: bool, batch_size: int = None):
        if use_batch_mode:
            self.memory_attention.model.stm.batched_memory(batch_size=batch_size, init_type='normal')
            self.batch_size = batch_size
        else:
            self.memory_attention.model.stm.single_memory(init_type='normal')
            self.batch_size = 1

    def reset_self_attn_cache(self):
        return self.decoder.model.reset_self_attn_cache()

    def update_stm(self, input_ids: torch.Tensor, attention_mask: torch.Tensor = None):
        with torch.no_grad():
            self.decoder.reset_self_attn_cache()
            self.decoder(input_ids, attention_mask=attention_mask, use_self_attn_cache=True)
            k, v, _ = self.decoder.get_stateful_kv_cache(stm_size=self.decoder_config['stm_size'])
            self.memory_attention(k, v, attention_mask=attention_mask)

    def init_stm_state(self, input_ids: torch.Tensor, attention_mask: torch.Tensor = None):
        self.update_stm(input_ids, attention_mask)

    def reset_stm_state(self):
        self.memory_attention.model.stm.reset()

    def export_stm_state(self) -> torch.Tensor:
        return self.memory_attention.model.stm.memory.clone().detach()

    def load_stm_state(self, stm_state: torch.Tensor):
        device = self.memory_attention.model.stm.memory.device
        self.memory_attention.model.stm.update_all(stm_state.to(device))

    def init_model(self, system_prompt: str = None, max_seq_len: int = 8192, device: torch.device = torch.device("cpu")):
        self.share_components()
        self.to(device)
        if system_prompt is not None:
            self.init_stm_state(**self.tokenize_system_prompt(system_prompt, max_seq_len, device))

    def _build_query_text(self, text: str, internal: str = None):
        if internal is not None:
            return f'{self.bos_token}{self.internal_token}{internal}{self.query_token}{text}'
        else:
            return f'{self.bos_token}{self.query_token}{text}'

    def tokenize_system_prompt(self, system: str, max_seq_len: int = 8192, device: torch.device = torch.device("cpu")) -> dict[str, dict[str, torch.Tensor]]:
        # Manually construct query: [BOS][Q]query
        system_text = f"{self.bos_token}{self.internal_token}{self.system_prompt_title}\n\n{system}{self.eos_token}"
        system_enc = self.tokenizer(
            system_text,
            max_length=max_seq_len,
            padding=False,
            truncation=True,
            return_tensors='pt',
            return_attention_mask=True,
            add_special_tokens=False  # Critical: We control all tokens
        )

        return {
            'input_ids': system_enc['input_ids'].to(device),
            'attention_mask': system_enc['attention_mask'].to(device),
        }

    def tokenize_query(self, text: str, max_seq_len: int = 8192, device: torch.device = torch.device("cpu"), internal: str = None):
        tokenized = self.tokenizer(
            self._build_query_text(text, internal),
            max_length=max_seq_len,
            truncation=True,
            padding=False,
            return_tensors='pt',
            return_attention_mask=True,
            add_special_tokens=False
        )

        return {
            'input_ids': tokenized['input_ids'].to(device),
            'attention_mask': tokenized['attention_mask'].to(device)
        }

    def tokenize_tool_result(self, text: str, max_seq_len: int = 8192, device: torch.device = torch.device("cpu"), internal: str = None):
        if internal is not None:
            full_text = f'{self.bos_token}{self.internal_token}{internal}{self.tool_use_token}{text}'
        else:
            full_text = f'{self.bos_token}{self.tool_use_token}{text}'

        tokenized = self.tokenizer(
            full_text,
            max_length=max_seq_len,
            truncation=True,
            padding=False,
            return_tensors='pt',
            return_attention_mask=True,
            add_special_tokens=False
        )

        return {
            'input_ids': tokenized['input_ids'].to(device),
            'attention_mask': tokenized['attention_mask'].to(device)
        }

    def tokenize_batch(self, texts: list[str], max_seq_len: int = 8192, device: torch.device = torch.device("cpu")):
        tokenized = self.tokenizer(
            [self._build_query_text(txt) for txt in texts],
            max_length=max_seq_len,
            truncation=True,
            padding='max_length',
            return_tensors='pt',
            return_attention_mask=True,
            add_special_tokens=False
        )

        return {
            'input_ids': tokenized['input_ids'].to(device),
            'attention_mask': tokenized['attention_mask'].to(device)
        }

    def tokenize_full_interaction(
            self, query: str = None, answer: str = None, think: str = None, tool_call: str = None, tool_use: str = None, internal: str = None,
            max_seq_len: int = 8192, device: torch.device = torch.device("cpu")
    ):
        assert query is not None or tool_use is not None, 'Full interaction should contain query or tool_use'
        assert (query is None or tool_use is not None) or (query is not None or tool_use is None), 'Full interaction cannot contain both query and tool_use'

        interaction_parts = [self.bos_token]

        if internal and len(internal) > 0:
            interaction_parts.append(f"{self.internal_token}{internal}")

        if tool_use and len(tool_use) > 0:
            interaction_parts.append(f"{self.tool_use_token}{tool_use}")
        elif query and len(query) > 0:
            interaction_parts.append(f"{self.query_token}{query}")

        if think and len(think) > 0:
            interaction_parts.append(f"{self.think_token}{think}")

        if answer and len(answer) > 0:
            interaction_parts.append(f"{self.answer_token}{answer}")

        if tool_call and len(tool_call) > 0:
            interaction_parts.append(f"{self.tool_call_token}{tool_call}")

        interaction_parts.append(self.eos_token)

        interaction_text = ''.join(interaction_parts)

        tokenized = self.tokenizer(
            interaction_text,
            max_length=max_seq_len,
            truncation=True,
            padding=False,
            return_tensors='pt',
            return_attention_mask=True,
            add_special_tokens=False
        )

        return {
            'input_ids': tokenized['input_ids'].to(device),
            'attention_mask': tokenized['attention_mask'].to(device)
        }

    def stringify_token(self, token_id: int, skip_special_tokens: bool = False, show_memory_update: bool = False) -> str:
        if token_id == -1:
            return '\n [Memory update]' if show_memory_update else ''
        elif token_id == -2:
            return '\n [Memory updated]' if show_memory_update else ''
        else:
            return decode_post_process(self.tokenizer.decode([token_id], skip_special_tokens=skip_special_tokens))

    def stringify_tokens(self, generated_ids: torch.Tensor, skip_special_tokens: bool = False) -> list[str]:
        decoded = []
        for token_id in generated_ids:
            # Trim after end token
            decoded.append(decode_post_process(self.tokenizer.decode([token_id], skip_special_tokens=skip_special_tokens)))

        return decoded

    def stringify_batch(self, generated_ids: torch.Tensor) -> list[str]:
        decoded = []
        for seq in generated_ids:
            # Trim after end token
            end_pos = (seq == self.sampler.eos_token_id).nonzero()
            if end_pos.size(0) > 0:
                seq = seq[:end_pos[0] + 1]
            decoded.append(decode_post_process(self.tokenizer.decode(seq)))

        return decoded

    def _generate_single_token(
            self,
            input_ids: torch.Tensor,
            temperature: float,
            top_k: int,
            top_p: float,
            attention_mask: torch.Tensor,
            use_self_attn_cache: bool = True,
            init_step: bool = False,
            is_auto_thinking: bool = False,
    ) -> tuple[int, torch.Tensor, torch.Tensor]:
        device = input_ids.device

        # Forward pass to get next token logits
        outputs = self.forward(
            input_ids[:, -1].unsqueeze(0) if not init_step else input_ids, attention_mask=attention_mask[:, -1].unsqueeze(0) if not init_step else attention_mask,
            use_self_attn_cache=use_self_attn_cache, current_positions=torch.tensor([[input_ids.size(-1) - 1]]).to(input_ids.device) if not init_step else None
        )

        if is_auto_thinking and init_step:
            answer_token_logits = outputs[:, -1, self.answer_token_id]
            think_token_logits = outputs[:, -1, self.think_token_id]

            if answer_token_logits > think_token_logits:
                next_token = self.answer_token_id
            else:
                next_token = self.think_token_id
        else:
            next_token_logits = outputs[:, -1, :]  # Get logits for next token
            # Apply sampling
            next_token = sample(
                next_token_logits,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p,
            )
            next_token = next_token.item()  # Extract scalar token

        next_token_ten = torch.tensor([[next_token]], device=device)
        next_input_ids = torch.cat([input_ids, next_token_ten], dim=1)
        new_one = torch.ones(1, 1, dtype=torch.bool, device=device)
        next_mask = torch.cat([attention_mask, new_one], dim=1) if attention_mask is not None else None

        # Yield the generated token
        return (
            next_token,
            next_input_ids,
            next_mask
        )

    def interact(
            self,
            input_ids: torch.Tensor,
            attention_mask: torch.Tensor = None,
            thinking_mode: Literal['auto', 'extended', 'fast'] = 'auto',
            temperature: float = 1.0,
            top_k: int = None,
            top_p: float = None,
            max_seq_len: int = 8192,
            use_self_attn_cache: bool = True,
    ) -> Iterator[int]:
        assert self.batch_size == 1 and input_ids.size(0) == 1, 'Batch size must be 1 in single interaction mode'

        with torch.no_grad():
            self.reset_self_attn_cache()

            if thinking_mode != 'auto':
                special_token = self.answer_token_id if thinking_mode == 'fast' else self.think_token_id
                input_ids = torch.cat([input_ids, torch.tensor([[special_token]]).to(input_ids.device)], dim=-1)
                attention_mask = torch.cat([attention_mask, torch.ones(1, 1, device=attention_mask.device)], dim=-1)

            for i in range(max_seq_len - input_ids.size(-1)):
                next_token, input_ids, attention_mask = self._generate_single_token(
                    input_ids, temperature, top_k, top_p, attention_mask,
                    use_self_attn_cache=use_self_attn_cache,
                    init_step=i == 0 or not use_self_attn_cache, is_auto_thinking=thinking_mode == 'auto'
                )

                if i == 0:
                    if thinking_mode == 'extended':
                        yield self.think_token_id
                    elif thinking_mode == 'fast':
                        yield self.answer_token_id

                yield next_token
                if next_token == self.eos_token_id:
                    break

            yield -1 # start memory update
            k, v, _ = self.decoder.get_stateful_kv_cache(stm_size=self.decoder_config['stm_size'], seq_len=input_ids.size(-1))
            self.memory_attention(k, v, attention_mask=None)
            yield -2 # finished memory update