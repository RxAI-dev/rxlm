import torch
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel
import math, random
from typing import Union, Callable, Any
from rxlm.training.base import BaseTrainer
from rxlm.training.ddp import distributed_value_mean, distributed_mean
from rxlm.training.utils import TokenizedDict, smart_concat
from rxlm.training.dataset import MrlCurriculumDataset
from rxlm.utils import cache_clean

from .sampler import BatchSampler
from .models import ProgressiveDMPOModel
from .reward import DMPORewardModel

class ProgressiveDMPOTrainer(BaseTrainer):
    def __init__(
            self,
            model: ProgressiveDMPOModel,
            ref_model: ProgressiveDMPOModel,
            device: torch.device,
            vocab_size: int,
            use_moe_aux_loss: bool = False,
            moe_aux_loss_scale: float = 0.01,
            max_seq_len: int = 256,
            pad_token_id: int = 0,
            think_token_id: int = 0,
            end_token_id: int = 0,
            answer_token_id: int = 0,
            use_system_prompt: bool = False,
            dataset_collate_fn: Callable[[list[Any]], dict[str, Any]] = MrlCurriculumDataset.collate_mrl_batch,
            reward_model: DMPORewardModel = None,
            collect_teacher_forcing: bool = False,
            collect_n_batches: int = 1000,
            train_batch_chunks: int = 1,
            beta: float = 0.1,
            skip_n_batches: int = 0,
            sft_lambda: float = 0.1,
            **kwargs
    ):
        super(ProgressiveDMPOTrainer, self).__init__(
            model, device, dataset_collate_fn=dataset_collate_fn, **kwargs
        )
        self.vocab_size = vocab_size
        self.use_moe_aux_loss = use_moe_aux_loss
        self.moe_aux_loss_scale = moe_aux_loss_scale
        self.get_batch_size = lambda batch: batch['query']['attention_mask'].size(0)
        self.total_inner_steps = 0
        self.valid_inner_steps = 0
        self.max_seq_len = max_seq_len
        self.pad_token_id = pad_token_id
        self.think_token_id = think_token_id
        self.answer_token_id = answer_token_id
        self.end_token_id = end_token_id
        self.use_system_prompt = use_system_prompt
        self.reward = reward_model
        self.collect_steps = 0
        self.collect_inner_steps = 0
        self.collect_teacher_forcing = collect_teacher_forcing
        self.collect_n_batches = collect_n_batches
        self.train_batch_chunks = train_batch_chunks
        self.total_train_steps = 0
        self.sft_lambda = sft_lambda

        ref_model.eval()
        for param in ref_model.parameters():
            param.requires_grad = False

        self.ref_model = ref_model.to(self.device)
        self.generator = None
        self.beta = beta

        self.skip_n_batches = skip_n_batches

        self.sampler_config = {
            'temperature': 1.0,
            'top_p': 0.95
        }

    def _get_model(self):
        model = self.model
        if isinstance(model, DistributedDataParallel):
            model = next(model.children())
        return model

    def reset_stm(self):
        self._get_model().reset_memory()

    def _generate_answer(self, query: dict, use_thinking: torch.Tensor):
        """Generate response using batch sampler with decoder."""
        # 1. Generate answer with BatchSampler - with autocast on/off
        if self.use_amp:
            with torch.amp.autocast(device_type=self.device.type, dtype=self.dtype):
                input_ids, attention_mask, _ = self.generator(
                    query['input_ids'],
                    query['attention_mask'],
                    max_gen_len=self.max_seq_len,
                    dtype=self.dtype,
                    use_thinking=use_thinking,
                    **self.sampler_config,
                )
        elif self.use_te_fp8:
            from transformer_engine.pytorch import fp8_autocast
            with fp8_autocast(enabled=True, fp8_recipe=self.fp8_recipe):
                input_ids, attention_mask, _ = self.generator(
                    query['input_ids'],
                    query['attention_mask'],
                    max_gen_len=self.max_seq_len,
                    dtype=self.dtype,
                    use_thinking=use_thinking,
                    **self.sampler_config,
                )
        else:
            input_ids, attention_mask, _ = self.generator(
                query['input_ids'],
                query['attention_mask'],
                max_gen_len=self.max_seq_len,
                dtype=self.dtype,
                use_thinking=use_thinking,
                **self.sampler_config
            )
        # 2. Convert generated answer to TokenizedDict
        generated_answer = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
        }

        return generated_answer

    def _calculate_reward(self, generated: TokenizedDict, reference: TokenizedDict,
                          saved_query: TokenizedDict, saved_answer: TokenizedDict):
        saved_interaction = smart_concat(saved_query, saved_answer, max_length=self.max_seq_len,
                                         pad_token_id=self.pad_token_id)

        return self.reward(generated, reference, saved_interaction)

    def _compute_reward(self, generated: TokenizedDict, reference: TokenizedDict,
                       saved_data: tuple[TokenizedDict, TokenizedDict]) -> torch.Tensor:
        """Compute reward based on memory retention (e.g., BLEU-4)."""
        # 1. Move sequences to GPU for reward calculation
        saved_query, saved_answer = self._move_multiple_batches(*saved_data)
        reference = self._move_batch(reference)

        # 2. Concat saved (previous) interaction and calculate reward using generated sequence, reference and saved data - with autocast on/off
        if self.use_amp:
            with torch.amp.autocast(device_type=self.device.type, dtype=self.dtype):
                reward = self._calculate_reward(
                    generated, reference, saved_query, saved_answer
                )
        elif self.use_te_fp8:
            from transformer_engine.pytorch import fp8_autocast
            with fp8_autocast(enabled=True, fp8_recipe=self.fp8_recipe):
                reward = self._calculate_reward(
                    generated, reference, saved_query, saved_answer
                )
        else:
            reward = self._calculate_reward(
                generated, reference, saved_query, saved_answer
            )

        return reward

    def _run_collection(self, batch: dict):
        collected_batch = {
            'query': batch['query'],
            'answer': batch['answer'],
            'interactions': batch['interactions'],
        }

        self.collect_steps += 1
        self.reset_stm()

        first_query, first_answer, interactions = batch['query'], batch['answer'], batch['interactions']

        number_of_inner_steps = len(interactions) + 1

        prev_query, prev_answer = self._move_multiple_batches(first_query, first_answer)

        inner_rewards = []

        for inner_step_idx in range(number_of_inner_steps):
            self.collect_inner_steps += 1
            if inner_step_idx == 0:
                next_query, next_answer = prev_query, prev_answer
            else:
                next_query, next_answer = self._move_multiple_batches(interactions[inner_step_idx - 1]['query'],
                                                                      interactions[inner_step_idx - 1]['answer'])

            use_thinking = next_answer['input_ids'][:, 0] == self.think_token_id
            generated_answer = self._generate_answer(next_query, use_thinking=use_thinking)

            self._update_collect_memory(next_query, next_answer)

            reward = self._compute_reward(
                generated_answer, next_answer, (prev_query, prev_answer)
            )

            step_reward = reward.mean().item()
            inner_rewards.append(step_reward)

            if inner_step_idx == 0:
                collected_batch['rejected'] = generated_answer
            else:
                collected_batch['interactions'][inner_step_idx - 1]['rejected'] = generated_answer

            print(f'Collect step: {self.collect_steps} / {inner_step_idx + 1} - mean reward: {step_reward}')
            if self.writer:
                self.writer.add_scalar(f'Collect/Reward (Step {inner_step_idx})', step_reward, self.collect_inner_steps)

            prev_query, prev_answer = self._move_multiple_batches(next_query, next_answer if self.collect_teacher_forcing else generated_answer)

            torch.distributed.barrier()

        mean_reward = sum(inner_rewards) / len(inner_rewards)
        print(f'Step: {self.collect_steps} - Conversation mean reward: {mean_reward}')
        if self.writer:
            self.writer.add_scalar(f'Collect/Reward (Full)', mean_reward, self.collect_steps)

        torch.distributed.barrier()

        return collected_batch

    def _update_collect_memory(self, query: TokenizedDict, answer: TokenizedDict):
        if self.use_amp:
            with torch.amp.autocast(device_type=self.device.type, dtype=self.dtype):
                self._update_memory(query, answer)
        elif self.use_te_fp8:
            from transformer_engine.pytorch import fp8_autocast
            with fp8_autocast(enabled=True, fp8_recipe=self.fp8_recipe):
                self._update_memory(query, answer)
        else:
            self._update_memory(query, answer)

    def _update_memory(self, query: TokenizedDict, answer: TokenizedDict):
        if self.collect_teacher_forcing:
            with torch.no_grad():
                self._get_model().decoder.reset_self_attn_cache()
                inputs = smart_concat(query, answer, self.max_seq_len, self.pad_token_id)
                self._get_model().decoder(inputs['input_ids'], attention_mask=inputs['attention_mask'], use_self_attn_cache=True)

                k, v, mask = self._get_model().decoder.get_stateful_kv_cache(stm_size=self._get_model().stm_size, seq_len=self._get_model().training_seq_len)
                self._get_model().memory_attention(k, v, attention_mask=inputs['attention_mask'])
        else:
            k, v, mask = self._get_model().decoder.get_stateful_kv_cache(stm_size=self._get_model().stm_size, seq_len=self._get_model().training_seq_len)
            self._get_model().memory_attention(k, v, attention_mask=mask[0])

    def _run_optimization(
            self,
            batch: dict,
            batch_idx: int,
            optimizer: torch.optim.Optimizer,
            scaler: torch.cuda.amp.GradScaler = None,
            scheduler: torch.optim.lr_scheduler.LRScheduler = None,
    ):
        self.optimizer_step_count = 0
        accumulated_tokens = torch.tensor(0, dtype=torch.long, device=self.device)
        self.total_steps += 1
        self.epoch_steps = batch_idx

        self.reset_stm()
        self.ref_model.reset_memory()

        first_query, first_answer, first_rejected, interactions = batch['query'], batch['answer'], batch['rejected'], batch['interactions']


        number_of_inner_steps = len(interactions) + 1

        prev_query, prev_answer, prev_rejected = self._move_multiple_batches(first_query, first_answer, first_rejected)

        for inner_step_idx in range(number_of_inner_steps):
            self.total_inner_steps += 1

            if inner_step_idx == 0:
                next_query, next_answer, next_rejected = prev_query, prev_answer, prev_rejected
            else:
                next_query, next_answer, next_rejected = self._move_multiple_batches(
                    interactions[inner_step_idx - 1]['query'],
                    interactions[inner_step_idx - 1]['answer'],
                    interactions[inner_step_idx - 1]['rejected']
                )

            self._get_model().clone_reset_memory()

            query_lens = next_query['attention_mask'].sum(dim=-1)
            answer_lens = next_answer['attention_mask'].sum(dim=-1)

            if self.use_amp:
                with torch.amp.autocast(device_type=self.device.type, dtype=self.dtype):
                    train_batch = {
                        'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                             pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(
                            batch['system']),
                        'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                             pad_token_id=self.pad_token_id),
                        'rejected': smart_concat(next_query, next_rejected, max_length=self.max_seq_len, pad_token_id=self.pad_token_id),
                    }
                    accumulated_tokens += train_batch['next']['attention_mask'].sum()
                    loss, _ = self.compute_loss(train_batch, query_lens=query_lens, answer_lens=answer_lens,
                                                is_first_step=not self.use_system_prompt and inner_step_idx == 0)
            elif self.use_te_fp8:
                from transformer_engine.pytorch import fp8_autocast
                with fp8_autocast(enabled=True, fp8_recipe=self.fp8_recipe):
                    train_batch = {
                        'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                             pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(
                            batch['system']),
                        'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                             pad_token_id=self.pad_token_id),
                        'rejected': smart_concat(next_query, next_rejected, max_length=self.max_seq_len, pad_token_id=self.pad_token_id),
                    }
                    accumulated_tokens += train_batch['next']['attention_mask'].sum()
                    loss, _ = self.compute_loss(train_batch, query_lens=query_lens, answer_lens=answer_lens,
                                                is_first_step=not self.use_system_prompt and inner_step_idx == 0)
            else:
                train_batch = {
                    'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                         pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(
                        batch['system']),
                    'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                         pad_token_id=self.pad_token_id),
                    'rejected': smart_concat(next_query, next_rejected, max_length=self.max_seq_len, pad_token_id=self.pad_token_id),
                }
                accumulated_tokens += train_batch['next']['attention_mask'].sum()
                loss, _ = self.compute_loss(train_batch, query_lens=query_lens, answer_lens=answer_lens,
                                            is_first_step=not self.use_system_prompt and inner_step_idx == 0)

            loss = loss / self.gradient_accumulation_steps

            if self.use_amp and scaler is not None:
                scaler.scale(loss).backward()
            else:
                loss.backward()

            self.optimizer_step_count += 1
            if self.optimizer_step_count % self.gradient_accumulation_steps == 0:
                # Clip gradients after accumulation
                if self.use_amp:
                    scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(self._get_model().trainable_parameters(), max_norm=1.0,
                                               error_if_nonfinite=False)
                if self.use_amp and scaler is not None:
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()

                optimizer.zero_grad()

                if scheduler is not None:
                    scheduler.step()

                self.optimizer_step_count = 0

            if self.writer and self.total_steps % self.tensorboard_interval:
                loss_item = loss.item() * self.gradient_accumulation_steps
                self._train_writer(
                    loss_item,
                    epoch_step=(batch_idx * number_of_inner_steps) + inner_step_idx,
                    inner_step=inner_step_idx,
                )

            prev_query, prev_answer = self._move_multiple_batches(next_query, next_answer)

            if self.writer and self.total_steps % self.tensorboard_interval:
                self.total_tokens += accumulated_tokens.item()
                accumulated_tokens = torch.tensor(0, dtype=torch.long, device=self.device)
                self.writer.add_scalar(
                    'Processed tokens',
                    self.total_tokens,
                    self.total_inner_steps
                )

            for callback in self.callbacks:
                should_stop = callback.on_batch_end(
                    self.model, (batch_idx * number_of_inner_steps) + inner_step_idx,
                                loss * self.gradient_accumulation_steps, train_batch['next']
                )
                if should_stop:
                    self.is_running = False

    def _run_collected(
            self,
            items: dict,
            optimizer: torch.optim.Optimizer,
            scaler: torch.cuda.amp.GradScaler = None,
            scheduler: torch.optim.lr_scheduler.LRScheduler = None,
    ):
        if self.train_batch_chunks > 1:
            def chunk_dict(item: dict):
                inputs = item['input_ids'].chunk(self.train_batch_chunks, dim=0)
                masks = item['attention_mask'].chunk(self.train_batch_chunks, dim=0)
                return {
                    'input_ids': inputs,
                    'attention_mask': masks,
                }

            q, a, r, i = items['query'], items['answer'], items['rejected'], items['interactions']

            queries = chunk_dict(q)
            answers = chunk_dict(a)
            rejections = chunk_dict(r)
            interactions = [{
                'query': chunk_dict(inter['query']),
                'answer': chunk_dict(inter['answer']),
                'rejected': chunk_dict(inter['rejected']),
            } for inter in i]

            for i in range(self.train_batch_chunks):
                self.total_train_steps += 1
                current_batch = {
                    'query': {
                        'input_ids': queries['input_ids'][i],
                        'attention_mask': queries['attention_mask'][i],
                    },
                    'answer': {
                        'input_ids': answers['input_ids'][i],
                        'attention_mask': answers['attention_mask'][i],
                    },
                    'rejected': {
                        'input_ids': rejections['input_ids'][i],
                        'attention_mask': rejections['attention_mask'][i],
                    },
                    'interactions': [{
                        'query': {
                            'input_ids': inter['query']['input_ids'][i],
                            'attention_mask': inter['query']['attention_mask'][i],
                        },
                        'answer': {
                            'input_ids': inter['answer']['input_ids'][i],
                            'attention_mask': inter['answer']['attention_mask'][i],
                        },
                        'rejected': {
                            'input_ids': inter['rejected']['input_ids'][i],
                            'attention_mask': inter['rejected']['attention_mask'][i],
                        },
                    } for inter in interactions]
                }

                self._run_optimization(current_batch, self.total_train_steps, optimizer, scaler, scheduler)
        else:
            self.total_train_steps += 1
            self._run_optimization(items, self.total_train_steps, optimizer, scaler, scheduler)

    def _run_epoch(
            self,
            dataloader: torch.utils.data.DataLoader,
            epoch: int,
            optimizer: torch.optim.Optimizer,
            batch_size: int,
            scaler: torch.cuda.amp.GradScaler = None,
            scheduler: torch.optim.lr_scheduler.LRScheduler = None,
    ) -> None:
        for callback in self.callbacks:
            callback.on_epoch_start(self.model, epoch)

        collected = []

        self.generator = BatchSampler(
            self.model, self.device,
            end_token_id=self.end_token_id, answer_token_id=self.answer_token_id,
            think_token_id=self.think_token_id, pad_token_id=self.pad_token_id
        )

        for batch_idx, batch in enumerate(dataloader):
            if batch_idx >= self.skip_n_batches:
                if not self.is_running:
                    break
                else:
                    if self.get_batch_size(batch) == batch_size:
                        with torch.no_grad():
                            collected.append(self._run_collection(batch))

                        if batch_idx % self.collect_n_batches == 0 and batch_idx > 0:
                            print(f'Collected {len(collected)} batches, running DMPO optimization')

                            self._get_model().memory_attention.model.stm.batched_memory(batch_size=batch_size // self.train_batch_chunks, init_type='normal')
                            self.ref_model.memory_attention.model.stm.batched_memory(batch_size=batch_size // self.train_batch_chunks, init_type='normal')

                            self.model.train()

                            for collected_idx, items in enumerate(collected):
                                cache_clean()
                                self._run_collected(items, optimizer, scaler, scheduler)

                            self.model.eval()

                            self._get_model().decoder.reset_self_attn_cache()
                            self.ref_model.decoder.reset_self_attn_cache()

                            optimizer.zero_grad(set_to_none=True)
                            del collected
                            collected = []

                            cache_clean()

                            for callback in self.callbacks:
                                should_stop = callback.on_iteration_end(self.model, self.total_train_steps)
                                if should_stop:
                                    self.is_running = False

                            self._get_model().memory_attention.model.stm.batched_memory(batch_size=batch_size, init_type='normal')
                            self.ref_model.memory_attention.model.stm.batched_memory(batch_size=batch_size, init_type='normal')

        if len(collected) > 0:
            self._get_model().memory_attention.model.stm.batched_memory(batch_size=batch_size // self.train_batch_chunks, init_type='normal')
            self.ref_model.memory_attention.model.stm.batched_memory(batch_size=batch_size // self.train_batch_chunks, init_type='normal')

            self.model.train()
            print(f'Collected {len(collected)} batches, running DMPO optimization')
            for collected_idx, items in enumerate(collected):
                cache_clean()
                self._run_collected(items, optimizer, scaler, scheduler)

            self._get_model().decoder.reset_self_attn_cache()
            self.ref_model.decoder.reset_self_attn_cache()

            optimizer.zero_grad(set_to_none=True)
            del collected

            cache_clean()

            for callback in self.callbacks:
                should_stop = callback.on_iteration_end(self.model, self.total_train_steps)
                if should_stop:
                    self.is_running = False

            self._get_model().memory_attention.model.stm.batched_memory(batch_size=batch_size, init_type='normal')
            self.ref_model.memory_attention.model.stm.batched_memory(batch_size=batch_size, init_type='normal')

            self.model.eval()

        if self.validation_dataset:
            self.validation_steps = 0
            self.valid_inner_steps = 0
            val_loss, val_metrics = self.validate(batch_size)
            if self.use_ddp:
                val_loss = distributed_value_mean(val_loss, device=self.device)

            self.validation_metrics[epoch] = val_metrics

            if self.writer:
                self._valid_writer(epoch, val_loss, val_metrics)

            for callback in self.callbacks:
                should_stop = callback.on_validation_end(self.model, epoch, val_loss, val_metrics)
                if should_stop:
                    self.is_running = False

        for callback in self.callbacks:
            should_stop = callback.on_epoch_end(self.model, epoch)
            if should_stop:
                self.is_running = False

        if self.writer:
            self.writer.flush()

    def _move_batch(self, batch: TokenizedDict) -> TokenizedDict:
        return {
                'input_ids': batch['input_ids'].to(self.device),
                'attention_mask': batch['attention_mask'].to(self.device),
            }

    def _move_multiple_batches(self, *batches: TokenizedDict) -> list[TokenizedDict]:
        return [self._move_batch(batch) for batch in batches]

    def _moe_aux_loss(self, main_loss: torch.Tensor) -> torch.Tensor:
        if not self.use_moe_aux_loss:
            return main_loss

        model = self._get_model()

        router_loss = model.decoder.model.moe_router_loss()
        loss = main_loss + self.moe_aux_loss_scale * router_loss

        if self.writer is not None and self.total_steps % self.tensorboard_interval:
            if self.model.training:
                self.writer.add_scalar('Router aux loss/Train', router_loss.item(), self.total_steps)
                self.writer.add_scalar('Model loss/Train', main_loss.item(), self.total_steps)
            else:
                self.writer.add_scalar('Router aux loss/Valid', router_loss.item(), self.total_steps)
                self.writer.add_scalar('Model loss/Valid', main_loss.item(), self.total_steps)

        return loss

    def _compute_log_probs(
            self,
            logits: torch.Tensor,
            targets: torch.Tensor,
            attention_mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # Shift for autoregressive prediction
        shifted_logits = logits[:, :-1].contiguous()
        shifted_targets = targets[:, 1:].contiguous()
        shifted_mask = attention_mask[:, 1:].contiguous()

        # Compute per-token log probabilities
        log_probs = F.log_softmax(shifted_logits, dim=-1)
        token_log_probs = torch.gather(
            log_probs, dim=-1, index=shifted_targets.unsqueeze(-1)
        ).squeeze(-1)

        # Mask padding and sum per sequence
        masked_log_probs = token_log_probs * shifted_mask.float()
        seq_log_probs = masked_log_probs.sum(dim=-1)

        # Normalize by sequence length
        seq_lengths = shifted_mask.sum(dim=-1).clamp(min=1)

        return seq_log_probs, seq_lengths

    def compute_dpo_loss(
            self,
            policy_accepted_log_probs: torch.Tensor,
            policy_rejected_log_probs: torch.Tensor,
            ref_accepted_log_probs: torch.Tensor,
            ref_rejected_log_probs: torch.Tensor,
            accepted_seq_lens: torch.Tensor,
            rejected_seq_lens: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute DPO loss.

        The standard DPO loss is:
        L = -log σ(β * ((log π(y_w) - log π(y_l)) - (log π_ref(y_w) - log π_ref(y_l))))

        """
        # Compute log-ratio differences
        accepted_diff = (policy_accepted_log_probs - ref_accepted_log_probs) / accepted_seq_lens.to(dtype=self.dtype)
        rejected_diff = (policy_rejected_log_probs - ref_rejected_log_probs) / rejected_seq_lens.to(dtype=self.dtype)

        # DPO loss
        logits = self.beta * (accepted_diff - rejected_diff)

        dpo_loss = -F.logsigmoid(logits).mean()

        sft_loss = -(policy_accepted_log_probs / accepted_seq_lens.to(dtype=self.dtype)).mean()

        return dpo_loss + self.sft_lambda * sft_loss

    def compute_loss(
            self, batch: dict[str, dict[str, torch.Tensor]], query_lens: torch.Tensor = None,
            answer_lens: torch.Tensor = None, is_first_step: bool = False
    ) -> tuple[torch.Tensor, torch.Tensor]:
        prev_mask = batch['prev']['attention_mask']

        accepted_inputs = batch['next']['input_ids']
        accepted_mask = batch['next']['attention_mask']

        rejected_inputs = batch['rejected']['input_ids']
        rejected_mask = batch['rejected']['attention_mask']

        accepted_logits, rejected_logits = self.model(
            accepted_inputs,
            rejected_inputs,
            accepted_mask=accepted_mask,
            rejected_mask=rejected_mask,
            prev_mask=prev_mask,
            is_first_step=is_first_step,
        )

        with torch.no_grad():
            ref_accepted_logits, ref_rejected_logits = self.ref_model(
                accepted_inputs,
                rejected_inputs,
                accepted_mask=accepted_mask,
                rejected_mask=rejected_mask,
                prev_mask=prev_mask,
                is_first_step=is_first_step,
            )

        accepted_answer_mask = accepted_mask.clone()
        rejected_answer_mask = rejected_mask.clone()
        for i in range(accepted_answer_mask.size(0)):
            accepted_answer_mask[i, :query_lens[i].item()] = 0
            rejected_answer_mask[i, :query_lens[i].item()] = 0

        accepted_log_probs, accepted_seq_lengths = self._compute_log_probs(
            accepted_logits, accepted_inputs, accepted_answer_mask
        )
        rejected_log_probs, rejected_seq_lengths = self._compute_log_probs(
            rejected_logits, rejected_inputs, rejected_answer_mask
        )
        ref_accepted_log_probs, _ = self._compute_log_probs(
            ref_accepted_logits, accepted_inputs, accepted_answer_mask
        )
        ref_rejected_log_probs, _ = self._compute_log_probs(
            ref_rejected_logits, rejected_inputs, rejected_answer_mask
        )

        loss = self.compute_dpo_loss(
            accepted_log_probs, rejected_log_probs,
            ref_accepted_log_probs, ref_rejected_log_probs,
            accepted_seq_lengths, rejected_seq_lengths,
        )

        loss = self._moe_aux_loss(loss)

        if self.writer and self.total_steps % self.tensorboard_interval:
            with torch.no_grad():
                normalized_accepted_log_probs = accepted_log_probs / accepted_seq_lengths.to(dtype=self.dtype)
                normalized_rejected_log_probs = rejected_log_probs / rejected_seq_lengths.to(dtype=self.dtype)
                reward_margin = (normalized_accepted_log_probs - normalized_rejected_log_probs).mean().item()
                accepted_reward = normalized_accepted_log_probs.mean().item()
                rejected_reward = normalized_rejected_log_probs.mean().item()

            self.writer.add_scalar('Reward/Margin', reward_margin, self.total_steps)
            self.writer.add_scalar('Reward/Accepted', accepted_reward, self.total_steps)
            self.writer.add_scalar('Reward/Rejected', rejected_reward, self.total_steps)


        return loss, accepted_logits

    def _train_writer(self, loss: float, epoch_step: int, inner_step: int) -> None:
        self.writer.add_scalar(
            'Loss/train',
            loss,
            self.total_inner_steps,
        )
        self.writer.add_scalar(
            'Loss/train last epoch',
            loss,
            epoch_step,
        )
        self.writer.add_scalar(
            'Perplexity/train',
            torch.exp(torch.tensor(loss)).item(),
            self.total_inner_steps,
        )

        self.writer.add_scalar(
            f'Loss/train (step: {inner_step})',
            loss,
            self.total_inner_steps,
        )
        self.writer.add_scalar(
            f'Perplexity/train (step: {inner_step})',
            torch.exp(torch.tensor(loss)).item(),
            self.total_inner_steps,
        )

    def _valid_writer(self, epoch: int, val_loss: float, val_metrics: dict):
        self.writer.add_scalar('Loss/Valid', val_loss, epoch)
        self.writer.add_scalar('Perplexity/Valid', math.exp(val_loss), epoch)
        if val_metrics['accuracy']:
            self.writer.add_scalar('Decoder node accuracy/Valid', val_metrics['node_accuracy'], epoch)
            self.writer.add_scalar('Decoder avg. accuracy/Valid', val_metrics['accuracy'], epoch)

    def _valid_step_writer(self, step: int, val_loss: float, val_metrics: dict, inner_step: int):
        self.writer.add_scalar('Loss/Valid step', val_loss, step)
        self.writer.add_scalar('Perplexity/Valid step', math.exp(val_loss), step)

        self.writer.add_scalar(f'Loss/Valid step (step: {inner_step})', val_loss, step)
        self.writer.add_scalar(f'Perplexity/Valid step (step: {inner_step})', math.exp(val_loss), step)

        if val_metrics['accuracy']:
            self.writer.add_scalar('Decoder node accuracy/Valid step', val_metrics['node_accuracy'], step)
            self.writer.add_scalar('Decoder avg. accuracy/Valid', val_metrics['accuracy'], step)

            self.writer.add_scalar(f'Decoder node accuracy/Valid step (step: {inner_step})',
                                   val_metrics['node_accuracy'], step)
            self.writer.add_scalar(f'Decoder avg. accuracy/Valid (step: {inner_step})', val_metrics['accuracy'], step)

    def evaluate(self, batch_size: int, test_dataset: torch.utils.data.Dataset = None) -> tuple[float, dict]:
        self.valid_inner_steps = 0
        return super().evaluate(batch_size, test_dataset)

    def validate(self, batch_size: int) -> tuple[float, dict]:
        self.model.eval()
        all_val_loss = torch.tensor(0.0).to(self.device)
        correct_alm = torch.tensor(0).to(self.device)
        total_alm = torch.tensor(0).to(self.device)

        val_dataloader = self._valid_loader(batch_size)

        processed = 0

        with torch.no_grad():
            for batch_idx, batch in enumerate(val_dataloader):
                if self.get_batch_size(batch) == batch_size:
                    processed += 1
                    val_loss = torch.tensor(0.0).to(self.device)

                    self.reset_stm()

                    first_query, first_answer, interactions = batch['query'], batch['answer'], batch['interactions']

                    number_of_inner_steps = len(interactions) + 1

                    prev_query, prev_answer = self._move_multiple_batches(first_query, first_answer)

                    for inner_step_idx in range(number_of_inner_steps):
                        self.total_inner_steps += 1

                        if inner_step_idx == 0:
                            next_query, next_answer = prev_query, prev_answer
                        else:
                            next_query, next_answer = self._move_multiple_batches(interactions[inner_step_idx - 1]['query'],
                                                                              interactions[inner_step_idx - 1]['answer'])

                        self._get_model().clone_reset_memory()

                        query_lens = next_query['attention_mask'].sum(dim=-1)
                        answer_lens = next_answer['attention_mask'].sum(dim=-1)

                        if self.use_amp:
                            with torch.amp.autocast(device_type=self.device.type, dtype=self.dtype):
                                valid_batch = {
                                    'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                                         pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(batch['system']),
                                    'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                                         pad_token_id=self.pad_token_id),
                                }
                                decoder_loss, decoder_logits = self.compute_loss(valid_batch, query_lens=query_lens, answer_lens=answer_lens, is_first_step=not self.use_system_prompt and inner_step_idx==0)
                        elif self.use_te_fp8:
                            from transformer_engine.pytorch import fp8_autocast
                            with fp8_autocast(enabled=True, fp8_recipe=self.fp8_recipe):
                                valid_batch = {
                                    'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                                         pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(batch['system']),
                                    'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                                         pad_token_id=self.pad_token_id),
                                }
                                decoder_loss, decoder_logits = self.compute_loss(valid_batch, query_lens=query_lens, answer_lens=answer_lens,
                                                                                 is_first_step=not self.use_system_prompt and inner_step_idx == 0)
                        else:
                            valid_batch = {
                                'prev': smart_concat(prev_query, prev_answer, max_length=self.max_seq_len,
                                                     pad_token_id=self.pad_token_id) if not self.use_system_prompt or inner_step_idx != 0 else self._move_batch(batch['system']),
                                'next': smart_concat(next_query, next_answer, max_length=self.max_seq_len,
                                                     pad_token_id=self.pad_token_id),
                            }
                            decoder_loss, decoder_logits = self.compute_loss(valid_batch, query_lens=query_lens, answer_lens=answer_lens, is_first_step=not self.use_system_prompt and inner_step_idx==0)

                        val_loss += decoder_loss

                        prev_query, prev_answer = self._move_multiple_batches(next_query, next_answer)

                        shifted_logits = decoder_logits[:, :-1].contiguous()
                        shifted_targets = valid_batch['next']['input_ids'][:, 1:].to(self.device).contiguous()

                        for i in range(shifted_targets.size(0)):
                            query_end = query_lens[i].item() - 1
                            answer_end = answer_lens[i].item() + query_end
                            shifted_targets[i, :query_end] = -100
                            shifted_targets[i, answer_end:] = -100

                        valid_alm_indices = shifted_targets != -100

                        if valid_alm_indices.any():
                            preds_alm = shifted_logits.argmax(-1)
                            correct_in_step = (preds_alm[valid_alm_indices] == shifted_targets[valid_alm_indices]).sum()
                            total_in_step = valid_alm_indices.sum()
                            correct_alm += correct_in_step
                            total_alm += total_in_step

                            step_acc = (correct_in_step / total_in_step * 100).item() if total_in_step > 0 else 0.0
                        else:
                            step_acc = 0.0

                        if self.use_ddp:
                            avg_step_acc = distributed_value_mean(step_acc, device=self.device)
                        else:
                            avg_step_acc = step_acc

                        if self.writer is not None:
                            self._valid_step_writer(self.valid_inner_steps, decoder_loss.item(), {
                                'accuracy': avg_step_acc,
                                'node_accuracy': step_acc,
                                'loss': decoder_loss.item()
                            }, inner_step=inner_step_idx)

                        for callback in self.callbacks:
                            callback.on_validation_batch_end(
                                self.model, (batch_idx * number_of_inner_steps) + inner_step_idx,
                                decoder_loss, valid_batch['next']
                            )

                    all_val_loss += val_loss / number_of_inner_steps

        avg_loss = all_val_loss / processed
        alm_acc = (correct_alm / total_alm * 100) if total_alm > 0 else torch.tensor(0.0).to(self.device)
        node_alm_acc = alm_acc.item()

        if self.use_ddp:
            avg_loss = distributed_mean(avg_loss)
            alm_acc = distributed_mean(alm_acc)

        metrics = {
            'accuracy': alm_acc.item(),
            'node_accuracy': node_alm_acc,
            'loss': avg_loss.item()
        }
        self.model.train()
        return avg_loss, metrics

