import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
from rxlm.transformers.sampler import sample_batch
from torch.nn.parallel import DistributedDataParallel

class BatchSampler:
    def __init__(
            self, model: nn.Module, device: torch.device,
            end_token_id: int, answer_token_id: int,
            think_token_id: int, pad_token_id: int = 0,
    ):
        self.model = model.to(device)
        self.device = device
        self.end_token_id = end_token_id
        self.answer_token_id = answer_token_id
        self.think_token_id = think_token_id
        self.pad_token_id = pad_token_id

    def _get_model(self):
        model = self.model
        if isinstance(model, DistributedDataParallel):
            model = next(model.children())
        return model

    def __call__(
            self,
            input_ids: torch.Tensor,
            attention_mask: torch.Tensor,
            temperature: float = 1.0,
            top_k: Optional[int] = None,
            top_p: Optional[float] = None,
            max_gen_len: int = 256,
            no_grad: bool = True,
            dtype: torch.dtype = torch.float32,
            use_thinking: torch.Tensor = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size, max_seq_len = input_ids.shape

        initial_lens = attention_mask.sum(dim=1).clamp(max=max_seq_len - 1)

        batch_range = torch.arange(batch_size, device=self.device)

        working_ids = input_ids.clone()
        working_mask = attention_mask.clone()

        working_ids[batch_range, initial_lens] = torch.where(use_thinking==True, self.think_token_id, self.answer_token_id)
        working_mask[batch_range, initial_lens] = 1
        initial_lens += 1

        current_lens = initial_lens.clone()
        finished = torch.zeros(batch_size, dtype=torch.bool, device=self.device)
        log_probs = torch.zeros((batch_size, max_gen_len), dtype=dtype, device=self.device)

        self._get_model().decoder.reset_self_attn_cache()

        for step in range(max_gen_len):
            active = (~finished) & (current_lens < max_seq_len)
            if not active.any():
                break

            max_len = current_lens.max()

            with torch.set_grad_enabled(not no_grad):
                indices = (current_lens - 1).to(self.device)
                if step == 0:
                    # prompt phase - cache input sequence
                    # Slice input and mask up to the current max length among active sequences
                    inputs = working_ids[:, :max_len]
                    masks = working_mask[:, :max_len]
                    logits, _ = self._get_model().decoder(
                        inputs,
                        attention_mask=masks,
                        use_self_attn_cache=True,
                        current_positions=None,
                    )
                else:
                    # generate phase, use last token
                    finished_tokens = finished.unsqueeze(-1)

                    selected_ids = working_ids[batch_range, indices].unsqueeze(-1)
                    selected_masks = working_mask[batch_range, indices].unsqueeze(-1)

                    inputs = torch.where(finished_tokens == 0, selected_ids, self.pad_token_id)
                    masks = torch.where(finished_tokens == 0, selected_masks, 0)

                    logits, _ = self._get_model().decoder(
                        inputs,
                        attention_mask=masks,
                        use_self_attn_cache=True,
                        current_positions=indices,
                    )

            # Get the last valid token index for each active sequence
            if step == 0:
                last_logits = logits[batch_range, indices]
            else:
                last_logits = logits[:, -1]

            # Sample next tokens and log probs
            next_tokens, step_log_probs = sample_batch(
                last_logits, temperature=temperature, top_k=top_k, top_p=top_p
            )

            # Empty first token sampling workaround
            # if self.use_first_empty_workaround and step == 0:
            #     random_token = torch.randint(self.first_normal_token_id, logits.size(-1), size=(), device=self.device)
            #     random_log_prob = torch.log(torch.rand(size=(), device=self.device))
            #
            #     next_tokens = torch.where(next_tokens == 0, random_token, next_tokens)
            #     step_log_probs = torch.where(next_tokens == 0, random_log_prob, step_log_probs)

            # Get positions to update
            positions_to_update = current_lens[active]
            active_range = batch_range[active]
            # Vectorized working tensors update
            working_ids[active_range, positions_to_update] = next_tokens[active]
            working_mask[active_range, positions_to_update] = 1
            # Vectorized log probs update
            log_probs[active_range, step] = step_log_probs[active].to(dtype=log_probs.dtype)
            # Update lens for active tokens
            current_lens += active.long()
            # Update finished tensor if some batch items stopped generation
            finished |= (next_tokens == self.end_token_id) & active

        # Extract generated tokens
        generated_ids = torch.zeros((batch_size, max_gen_len), dtype=torch.long, device=self.device)
        generated_mask = torch.zeros((batch_size, max_gen_len), dtype=torch.bool, device=self.device)
        for i in range(batch_size):
            start = initial_lens[i].item()
            end = current_lens[i].item()
            gen_len = min(end - start + 1, max_gen_len)  # +1 for added [A] token
            if gen_len > 0:
                generated_ids[i, :gen_len] = working_ids[i, start - 1:end]  # -1 to include [A] token
                generated_mask[i, :gen_len] = working_mask[i, start - 1:end]  # -1 to include [A] token

        return generated_ids, generated_mask, log_probs
