import torch
from torch.utils.data import Dataset, IterableDataset, get_worker_info
from datasets import Dataset as HfDataset, load_dataset, concatenate_datasets, IterableDataset as HfIterableDataset
from transformers import PreTrainedTokenizer, PreTrainedTokenizerFast
from rxlm.training.tokenizer import load_tokenizer_from_hf_hub
import torch.distributed as dist

from typing import Union, TypedDict, Optional, TypeAlias, Any, Literal


class HybridReasoningDecoderSftDataset(Dataset):
    """
    Dataset for Interaction SFT with hybrid reasoning and agentic tools support.

    Supports the new RxT-Beta Interaction Template with special tokens:
    - [Q] - query block
    - [A] - answer block
    - [T] - thinking/reasoning block
    - [C] - agentic tool call
    - [U] - agentic tool use
    - [I] - internal instruction

    The template structure is:
    - Fast answer: [I] internal [Q] query [A] answer [C] tool_call
    - Extended thinking: [I] internal [Q] query [T] think [A] answer [C] tool_call
    - Tool use: [I] internal [U] tool_use [T] think [A] answer [C] tool_call

    For training loss:
    - Masked (ignored): internal, query, tool_use tokens
    - Used for loss: think, answer, tool_call tokens
    """

    def __init__(
            self,
            interactions: Union[list[dict], HfDataset],
            tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast],
            max_seq_len: int = 1024,
            # Field names in dataset
            query_field: str = 'query',
            answer_field: str = 'answer',
            think_field: str = 'think',
            tool_call_field: str = 'tool_call',
            tool_use_field: str = 'tool_use',
            internal_field: str = 'internal',
            # Special tokens (text versions for manual tokenization)
            query_token: str = '[Q]',
            answer_token: str = '[A]',
            think_token: str = '[T]',
            tool_call_token: str = '[C]',
            tool_use_token: str = '[U]',
            internal_token: str = '[I]',
            bos_token: str = '[BOS]',
            eos_token: str = '[EOS]',
            # Other options
            ignore_index: int = -100,
            cache_tokenized: bool = False,
            cache_remove_text: bool = True,
            ignore_answer_special_tokens: bool = False,
            vocab_size: int = None,
            **kwargs,
    ):
        super(HybridReasoningDecoderSftDataset, self).__init__(**kwargs)
        self.interactions = interactions
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len

        # Field names
        self.query_field = query_field
        self.answer_field = answer_field
        self.think_field = think_field
        self.tool_call_field = tool_call_field
        self.tool_use_field = tool_use_field
        self.internal_field = internal_field

        # Special tokens
        self.query_token = query_token
        self.answer_token = answer_token
        self.think_token = think_token
        self.tool_call_token = tool_call_token
        self.tool_use_token = tool_use_token
        self.internal_token = internal_token
        self.bos_token = bos_token
        self.eos_token = eos_token

        self.ignore_index = ignore_index
        self.cache_tokenized = cache_tokenized
        self.cache_remove_text = cache_remove_text
        self.ignore_answer_special_tokens = ignore_answer_special_tokens

        self.is_pre_tokenized = False
        self.is_list = isinstance(self.interactions, list)
        self.inputs = []
        self.vocab_size = vocab_size if vocab_size is not None else self.tokenizer.vocab_size

    def __len__(self):
        return len(self.inputs if self.is_pre_tokenized else self.interactions)

    def _build_interaction_text(self, item: dict) -> str:
        """
        Builds the full interaction text from components.

        Template structure:
        [BOS][I]internal[Q|U]query_or_tool_use[T]think[A]answer[C]tool_call[EOS]

        All components except [BOS] and [EOS] are optional.
        """
        parts = [self.bos_token]

        # Internal instruction (optional, at the start)
        internal = item.get(self.internal_field)
        if internal:
            parts.append(f"{self.internal_token}{internal}")

        # Either query or tool_use (mutually exclusive)
        tool_use = item.get(self.tool_use_field)
        query = item.get(self.query_field)

        if tool_use:
            parts.append(f"{self.tool_use_token}{tool_use}")
        elif query:
            parts.append(f"{self.query_token}{query}")

        # Think block (optional)
        think = item.get(self.think_field)
        if think:
            parts.append(f"{self.think_token}{think}")

        # Answer block (optional - might be skipped for direct tool call)
        answer = item.get(self.answer_field)
        if answer:
            parts.append(f"{self.answer_token}{answer}")

        # Tool call (optional, at the end)
        tool_call = item.get(self.tool_call_field)
        if tool_call:
            parts.append(f"{self.tool_call_token}{tool_call}")

        parts.append(self.eos_token)

        return ''.join(parts)

    def _create_masked_labels(self, input_ids: torch.Tensor, item: dict) -> torch.Tensor:
        """
        Creates masked labels for training.

        Masked (ignore_index): internal, query, tool_use tokens
        Used for loss: think, answer, tool_call tokens
        """
        labels = input_ids.clone()

        # Get token IDs
        query_token_id = self.tokenizer.convert_tokens_to_ids(self.query_token)
        answer_token_id = self.tokenizer.convert_tokens_to_ids(self.answer_token)
        think_token_id = self.tokenizer.convert_tokens_to_ids(self.think_token)
        tool_call_token_id = self.tokenizer.convert_tokens_to_ids(self.tool_call_token)
        tool_use_token_id = self.tokenizer.convert_tokens_to_ids(self.tool_use_token)
        internal_token_id = self.tokenizer.convert_tokens_to_ids(self.internal_token)
        eos_token_id = self.tokenizer.convert_tokens_to_ids(self.eos_token)

        # Tokens that start sections to be masked (input sections)
        mask_start_tokens = {query_token_id, tool_use_token_id, internal_token_id}
        # Tokens that start sections for training (output sections)
        train_start_tokens = {think_token_id, answer_token_id, tool_call_token_id}
        # End tokens
        end_tokens = {eos_token_id}

        in_train_section = False
        for i in range(len(input_ids)):
            token = input_ids[i].item()

            if token in train_start_tokens:
                in_train_section = True
                if self.ignore_answer_special_tokens:
                    # Mask the special token itself
                    labels[i] = self.ignore_index
            elif token in mask_start_tokens:
                in_train_section = False
                labels[i] = self.ignore_index
            elif token in end_tokens:
                in_train_section = False
            elif not in_train_section:
                labels[i] = self.ignore_index

        return labels

    def get_tokenized_item(self, idx: int, item: dict = None) -> dict:
        if self.is_pre_tokenized:
            return self.inputs[idx]

        if item is None:
            item = self.interactions[idx]

        # Build the full interaction text
        text = self._build_interaction_text(item)

        # Tokenize with skip_special_tokens=False to preserve our control tokens
        inputs = self.tokenizer(
            text,
            max_length=self.max_seq_len,
            truncation=True,
            padding='max_length',
            return_tensors='pt',
            add_special_tokens=False,  # We control all tokens manually
        )

        input_ids = inputs['input_ids'][0]
        attention_mask = inputs['attention_mask'][0]

        # Fix any out-of-vocab tokens
        if not (input_ids < self.vocab_size).all():
            input_ids[input_ids >= self.vocab_size] = self.tokenizer.unk_token_id
        if not (input_ids >= 0).all():
            input_ids[input_ids < 0] = self.tokenizer.unk_token_id

        # Create masked labels for decoder
        decoder_targets = self._create_masked_labels(input_ids, item)

        result = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'targets': decoder_targets,
        }

        if self.cache_tokenized:
            self.inputs.append(result)
            if len(self.inputs) == len(self.interactions):
                self.is_pre_tokenized = True
                if self.cache_remove_text:
                    del self.interactions
                    self.interactions = None

        return result

    def __getitem__(self, idx: int) -> dict[str, dict[str, torch.Tensor]]:
        return self.get_tokenized_item(idx)

    def pre_tokenize(self, verbose: bool = False, log_interval: int = 10_000):
        """Pre-tokenizes all items for faster training."""
        if not self.is_pre_tokenized:
            num_items = len(self.interactions)
            items = self.interactions if self.is_list else self.interactions.to_list()
            del self.interactions
            self.interactions = None
            for index in range(num_items):
                self.inputs.append(self.get_tokenized_item(index, item=items.pop()))
                if verbose and index % log_interval == 0:
                    print(f'Processed {index + 1}/{num_items}')
            self.is_pre_tokenized = True

    @classmethod
    def from_hf_hub(
            cls,
            dataset_id: str,
            subset: str = None,
            split: str = 'train',
            tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
            tokenizer_hub_id: str = None,
            max_seq_len: int = 1024,
            load_kwargs: dict = None,
            load_tokenizer_kwargs: dict = None,
            **kwargs
    ):
        """Load dataset from HuggingFace Hub."""
        assert tokenizer is not None or tokenizer_hub_id is not None

        if load_kwargs is None:
            load_kwargs = {}
        if load_tokenizer_kwargs is None:
            load_tokenizer_kwargs = {}

        if tokenizer is None:
            tokenizer = load_tokenizer_from_hf_hub(tokenizer_hub_id, **load_tokenizer_kwargs)

        hf_dataset = load_dataset(dataset_id, subset, split=split, **load_kwargs) if subset else load_dataset(dataset_id, split=split, **load_kwargs)

        return cls(hf_dataset, tokenizer, max_seq_len=max_seq_len, **kwargs)


class HybridReasoningIterableDecoderSftDataset(IterableDataset):
    """
    Dataset for Interaction SFT with hybrid reasoning and agentic tools support.

    Supports the new RxT-Beta Interaction Template with special tokens:
    - [Q] - query block
    - [A] - answer block
    - [T] - thinking/reasoning block
    - [C] - agentic tool call
    - [U] - agentic tool use
    - [I] - internal instruction

    The template structure is:
    - Fast answer: [I] internal [Q] query [A] answer [C] tool_call
    - Extended thinking: [I] internal [Q] query [T] think [A] answer [C] tool_call
    - Tool use: [I] internal [U] tool_use [T] think [A] answer [C] tool_call

    For training loss:
    - Masked (ignored): internal, query, tool_use tokens
    - Used for loss: think, answer, tool_call tokens
    """

    def __init__(
            self,
            interactions: Union[list[dict], HfDataset],
            tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast],
            max_seq_len: int = 1024,
            # Field names in dataset
            query_field: str = 'query',
            answer_field: str = 'answer',
            think_field: str = 'think',
            tool_call_field: str = 'tool_call',
            tool_use_field: str = 'tool_use',
            internal_field: str = 'internal',
            # Special tokens (text versions for manual tokenization)
            query_token: str = '[Q]',
            answer_token: str = '[A]',
            think_token: str = '[T]',
            tool_call_token: str = '[C]',
            tool_use_token: str = '[U]',
            internal_token: str = '[I]',
            bos_token: str = '[BOS]',
            eos_token: str = '[EOS]',
            # Other options
            ignore_index: int = -100,
            ignore_answer_special_tokens: bool = False,
            **kwargs,
    ):
        super(HybridReasoningIterableDecoderSftDataset, self).__init__(**kwargs)
        self.interactions = interactions
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len

        # Field names
        self.query_field = query_field
        self.answer_field = answer_field
        self.think_field = think_field
        self.tool_call_field = tool_call_field
        self.tool_use_field = tool_use_field
        self.internal_field = internal_field

        # Special tokens
        self.query_token = query_token
        self.answer_token = answer_token
        self.think_token = think_token
        self.tool_call_token = tool_call_token
        self.tool_use_token = tool_use_token
        self.internal_token = internal_token
        self.bos_token = bos_token
        self.eos_token = eos_token

        self.ignore_index = ignore_index
        self.ignore_answer_special_tokens = ignore_answer_special_tokens

        self.is_list = isinstance(self.interactions, list)

    def _build_interaction_text(self, item: dict) -> str:
        """
        Builds the full interaction text from components.

        Template structure:
        [BOS][I]internal[Q|U]query_or_tool_use[T]think[A]answer[C]tool_call[EOS]

        All components except [BOS] and [EOS] are optional.
        """
        parts = [self.bos_token]

        # Internal instruction (optional, at the start)
        internal = item.get(self.internal_field)
        if internal:
            parts.append(f"{self.internal_token}{internal}")

        # Either query or tool_use (mutually exclusive)
        tool_use = item.get(self.tool_use_field)
        query = item.get(self.query_field)

        if tool_use:
            parts.append(f"{self.tool_use_token}{tool_use}")
        elif query:
            parts.append(f"{self.query_token}{query}")

        # Think block (optional)
        think = item.get(self.think_field)
        if think:
            parts.append(f"{self.think_token}{think}")

        # Answer block (optional - might be skipped for direct tool call)
        answer = item.get(self.answer_field)
        if answer:
            parts.append(f"{self.answer_token}{answer}")

        # Tool call (optional, at the end)
        tool_call = item.get(self.tool_call_field)
        if tool_call:
            parts.append(f"{self.tool_call_token}{tool_call}")

        parts.append(self.eos_token)

        return ''.join(parts)

    def _create_masked_labels(self, input_ids: torch.Tensor, item: dict) -> torch.Tensor:
        """
        Creates masked labels for training.

        Masked (ignore_index): internal, query, tool_use tokens
        Used for loss: think, answer, tool_call tokens
        """
        labels = input_ids.clone()

        # Get token IDs
        query_token_id = self.tokenizer.convert_tokens_to_ids(self.query_token)
        answer_token_id = self.tokenizer.convert_tokens_to_ids(self.answer_token)
        think_token_id = self.tokenizer.convert_tokens_to_ids(self.think_token)
        tool_call_token_id = self.tokenizer.convert_tokens_to_ids(self.tool_call_token)
        tool_use_token_id = self.tokenizer.convert_tokens_to_ids(self.tool_use_token)
        internal_token_id = self.tokenizer.convert_tokens_to_ids(self.internal_token)
        eos_token_id = self.tokenizer.convert_tokens_to_ids(self.eos_token)

        # Tokens that start sections to be masked (input sections)
        mask_start_tokens = {query_token_id, tool_use_token_id, internal_token_id}
        # Tokens that start sections for training (output sections)
        train_start_tokens = {think_token_id, answer_token_id, tool_call_token_id}
        # End tokens
        end_tokens = {eos_token_id}

        in_train_section = False
        for i in range(len(input_ids)):
            token = input_ids[i].item()

            if token in train_start_tokens:
                in_train_section = True
                if self.ignore_answer_special_tokens:
                    # Mask the special token itself
                    labels[i] = self.ignore_index
            elif token in mask_start_tokens:
                in_train_section = False
                labels[i] = self.ignore_index
            elif token in end_tokens:
                in_train_section = False
            elif not in_train_section:
                labels[i] = self.ignore_index

        return labels

    def get_tokenized_item(self, item: dict) -> dict:
        # Build the full interaction text
        text = self._build_interaction_text(item)

        # Tokenize with skip_special_tokens=False to preserve our control tokens
        inputs = self.tokenizer(
            text,
            max_length=self.max_seq_len,
            truncation=True,
            padding='max_length',
            return_tensors='pt',
            add_special_tokens=False,  # We control all tokens manually
        )

        input_ids = inputs['input_ids'][0]
        attention_mask = inputs['attention_mask'][0]

        # Fix any out-of-vocab tokens
        if not (input_ids < self.tokenizer.vocab_size).all():
            input_ids[input_ids >= self.tokenizer.vocab_size] = self.tokenizer.unk_token_id
        if not (input_ids >= 0).all():
            input_ids[input_ids < 0] = self.tokenizer.unk_token_id

        # Create masked labels for decoder
        decoder_targets = self._create_masked_labels(input_ids, item)

        result = {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'targets': decoder_targets,
        }

        return result

    def __iter__(self):
        for example in self.interactions:
            inputs = self.get_tokenized_item(example)

            attention_mask = inputs['attention_mask']
            input_ids = inputs['input_ids']
            targets = inputs['targets']

            yield {
                'input_ids': input_ids,
                'targets': targets,
                'attention_mask': attention_mask,
            }

    @classmethod
    def from_hf_hub(
            cls,
            dataset_id: str,
            subset: str = None,
            split: str = 'train',
            tokenizer: Union[PreTrainedTokenizer, PreTrainedTokenizerFast] = None,
            tokenizer_hub_id: str = None,
            max_seq_len: int = 1024,
            load_kwargs: dict = None,
            load_tokenizer_kwargs: dict = None,
            **kwargs
    ):
        """Load dataset from HuggingFace Hub."""
        assert tokenizer is not None or tokenizer_hub_id is not None

        if load_kwargs is None:
            load_kwargs = {}
        if load_tokenizer_kwargs is None:
            load_tokenizer_kwargs = {}

        if tokenizer is None:
            tokenizer = load_tokenizer_from_hf_hub(tokenizer_hub_id, **load_tokenizer_kwargs)

        hf_dataset = load_dataset(dataset_id, subset, split=split, streaming=True, **load_kwargs) if subset else load_dataset(dataset_id, split=split, streaming=True, **load_kwargs)

        return cls(hf_dataset, tokenizer, max_seq_len=max_seq_len, **kwargs)
