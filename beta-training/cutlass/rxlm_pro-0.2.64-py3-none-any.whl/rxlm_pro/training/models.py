import torch
import torch.nn as nn
from typing import Iterator

class RcMemoryAttentionTrainingModel(nn.Module):
    def __init__(
            self,
            decoder: nn.Module,
            memory_attention: nn.Module,
            skip_stm_in_decoder: bool = False,
            stm_size: int = 4096,
            training_seq_len: int = 4096,
            *args,
            **kwargs
    ):
        super(RcMemoryAttentionTrainingModel, self).__init__(*args, **kwargs)
        self.decoder = decoder
        self.memory_attention = memory_attention
        self.skip_stm_in_decoder = skip_stm_in_decoder
        self.stm_size = stm_size
        self.training_seq_len = training_seq_len

    def trainable_parameters(self) -> Iterator[torch.Tensor]:
        return self.memory_attention.parameters()

    def reset_memory(self, init_type: str = None):
        self.memory_attention.reset_memory(init_type)

    def clone_reset_memory(self):
        self.memory_attention.clone_reset_memory()

    def get_memory_state(self):
        return self.memory_attention.model.stm.memory

    def _get_noised_kv(self, x: torch.Tensor, noise_level: float = 0.0) -> torch.Tensor:
        x_target = x[:, :, :self.training_seq_len, :]
        return x_target + noise_level * torch.randn_like(x_target)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor = None, noise_level: float = 0.0) -> tuple[torch.Tensor, torch.Tensor]:
        with torch.no_grad():
            self.decoder.reset_self_attn_cache()
            _, hidden_states = self.decoder(input_ids, attention_mask=attention_mask, skip_stm=self.skip_stm_in_decoder, use_self_attn_cache=True)
            k, v, mask = self.decoder.get_stateful_kv_cache(stm_size=self.stm_size)
            k = [self._get_noised_kv(key, noise_level) for key in k]
            v = [self._get_noised_kv(val, noise_level) for val in v]

        new_stm = self.memory_attention(k, v, attention_mask=attention_mask)
        return new_stm, hidden_states


class EncoderMock(nn.Module):
    """Required for rxlm training pipeline compatibility"""
    def freeze_all(self):
        pass
    def unfreeze_all(self, a: bool, b: bool):
        pass


class RcMemoryAwareModel(nn.Module):
    def __init__(
            self,
            decoder: nn.Module,
            memory_attention: nn.Module,
            stm_size: int,
            train_only_decoder: bool = False,
            training_seq_len: int = 4096,
            *args,
            **kwargs
    ):
        super(RcMemoryAwareModel, self).__init__(*args, **kwargs)
        self.encoder = EncoderMock()
        self.decoder = decoder
        self.memory_attention = memory_attention
        self.train_only_decoder = train_only_decoder
        self.stm_size = stm_size
        self.training_seq_len = training_seq_len

    def trainable_parameters(self) -> Iterator[torch.Tensor]:
        if self.train_only_decoder:
            return self.decoder.parameters()
        else:
            params_set = set(
                list(self.decoder.parameters()) + list(self.memory_attention.parameters())
            )
            return iter(params_set)

    def clone_reset_memory(self):
        self.memory_attention.clone_reset_memory()

    def reset_memory(self, init_type: str = None):
        self.memory_attention.reset_memory(init_type)

    def forward(self, x_e: torch.Tensor, x_d: torch.Tensor, encoder_mask: torch.Tensor = None, decoder_mask: torch.Tensor = None, is_first_step: bool = False) -> torch.Tensor:
        if not is_first_step:
            with torch.set_grad_enabled(not self.train_only_decoder):
                k, v, mask = self.decoder.get_stateful_kv_cache(self.stm_size, seq_len=self.training_seq_len)
                k = [key.detach().to(x_d.device) for key in k]
                v = [val.detach().to(x_d.device) for val in v]
                self.memory_attention(k, v, attention_mask=encoder_mask)

        self.decoder.reset_self_attn_cache()
        logits, _ = self.decoder(x_d, attention_mask=decoder_mask, use_self_attn_cache=True)
        return logits

class ProgressiveDMPOModel(nn.Module):
    def __init__(
            self,
            decoder: nn.Module,
            memory_attention: nn.Module,
            stm_size: int,
            training_seq_len: int = 4096,
            *args,
            **kwargs
    ):
        super(ProgressiveDMPOModel, self).__init__(*args, **kwargs)
        self.decoder = decoder
        self.memory_attention = memory_attention
        self.stm_size = stm_size
        self.training_seq_len = training_seq_len

    def trainable_parameters(self) -> Iterator[torch.Tensor]:
        params_set = set(
            list(self.decoder.parameters()) + list(self.memory_attention.parameters())
        )
        return iter(params_set)

    def clone_reset_memory(self):
        self.memory_attention.clone_reset_memory()

    def reset_memory(self, init_type: str = None):
        self.memory_attention.reset_memory(init_type)

    def forward(
            self, accepted: torch.Tensor, rejected: torch.Tensor,
            accepted_mask: torch.Tensor = None, rejected_mask: torch.Tensor = None,
            prev_mask: torch.Tensor = None, is_first_step: bool = False
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # 1. Update STM with previous accepted interaction
        if not is_first_step:
            k, v, mask = self.decoder.get_stateful_kv_cache(self.stm_size, seq_len=self.training_seq_len)
            k = [key.detach().to(accepted.device) for key in k]
            v = [val.detach().to(accepted.device) for val in v]
            self.memory_attention(k, v, attention_mask=prev_mask)

        # 2. Process rejected example
        self.decoder.reset_self_attn_cache()
        rejected_logits, _ = self.decoder(rejected, attention_mask=rejected_mask, use_self_attn_cache=True)

        # 3. Process accepted example and left populated cache for next interaction
        self.decoder.reset_self_attn_cache()
        accepted_logits, _ = self.decoder(accepted, attention_mask=accepted_mask, use_self_attn_cache=True)

        return accepted_logits, rejected_logits
