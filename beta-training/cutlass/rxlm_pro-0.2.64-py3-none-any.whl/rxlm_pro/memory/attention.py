import torch
from torch import nn

from rxlm.memory.stm import ShortTermMemory

class RcGatedStmMemoryAttention(nn.Module):
    def __init__(
            self,
            stm: ShortTermMemory,
            attention_layers: nn.ModuleList,
            memory_norm_layers: nn.ModuleList,
            memory_input_norm_layers: nn.ModuleList,
            residual_gate_layers: nn.ModuleList,
            mean_attention_layers: nn.ModuleList,
            mean_memory_norm_layers: nn.ModuleList,
            mean_residual_gate_layers: nn.ModuleList,
            interlayer_gate_layers: nn.ModuleList,
            mean_stm_norm: nn.Module,
            **kwargs
    ):
        super(RcGatedStmMemoryAttention, self).__init__(**kwargs)

        self.stm = stm
        self.attention_layers = attention_layers
        self.num_layers = len(attention_layers)
        self.memory_norm_layers = memory_norm_layers
        self.memory_input_norm_layers = memory_input_norm_layers
        self.residual_gate_layers = residual_gate_layers
        assert (len(self.attention_layers) == len(self.memory_norm_layers) ==
                len(self.residual_gate_layers) == len(self.memory_input_norm_layers) ==
                self.stm.memory.size(0))

        self.mean_attention_layers = mean_attention_layers
        self.mean_memory_norm_layers = mean_memory_norm_layers
        self.mean_stm_norm = mean_stm_norm
        self.mean_residual_gate_layers = mean_residual_gate_layers
        self.interlayer_gate_layers = interlayer_gate_layers
        assert (len(self.mean_attention_layers) == len(self.mean_memory_norm_layers) ==
                len(self.mean_residual_gate_layers) == len(self.interlayer_gate_layers) == self.num_layers)

    def update_max_len(self, max_seq_len: int):
        for i in range(self.num_layers):
            if self.attention_layers[i].rope is not None:
                self.attention_layers[i].rope.update_max_len(max_seq_len)

    def _main_attention(
            self,
            layer_idx: int,
            layer_stm: torch.Tensor,
            keys: list[torch.Tensor],
            values: list[torch.Tensor],
            past_layer_stm: torch.Tensor,
            mask: torch.Tensor = None,
    ) -> torch.Tensor:
        layer_keys = keys[layer_idx]
        layer_values = values[layer_idx]

        b, h, t, d  = layer_keys.size()

        layer_keys = layer_keys.transpose(1, 2).reshape(b, t, h * d)
        layer_values = layer_values.transpose(1, 2).reshape(b, t, h * d)

        # 1. Normalize encoded layer data
        norm_keys = self.memory_input_norm_layers[layer_idx](layer_keys)
        norm_values = self.memory_input_norm_layers[layer_idx](layer_values)
        # 2. Normalize STM layer
        normalized_layer_stm = self.memory_norm_layers[layer_idx](layer_stm)

        # 3. Calculate memory attention
        new_layer_stm = self.attention_layers[layer_idx](
            normalized_layer_stm,
            norm_keys,
            norm_values,
            mask=mask.unsqueeze(1).unsqueeze(1).bool() if mask is not None else None,
        )
        # 4. Combine new updated layer state with current STM state in residual gate
        return self.residual_gate_layers[layer_idx](past_layer_stm, new_layer_stm)  # residual

    def forward(self, keys: list[torch.Tensor], values: list[torch.Tensor], attention_mask: torch.Tensor = None) -> torch.Tensor:
        # 2. Init new empty STM
        new_stm = torch.zeros_like(self.stm.memory)

        # 3. Get mean STM value from layers for mean interlayer memory attention
        mean_stm = self.stm.memory.mean(dim=0) # [batch_size, stm_size, embed_dim]
        # 4. Normalize mean STM layer
        normalized_mean_stm = self.mean_stm_norm(mean_stm)

        # 5. Run Short-Term Memory update for all layers
        for i in range(self.num_layers):
            # 6. Get current layer STM value
            layer_stm = self.stm(i)

            # 7. Gated self/interlayer memory attention
            # a) normalize STM layer value
            pre_normalized_layer_stm = self.mean_memory_norm_layers[i](layer_stm)
            # b) combine interlayer and current layer data with gate
            self_interlayer_stm_input = self.interlayer_gate_layers[i](pre_normalized_layer_stm, normalized_mean_stm)
            # c) calculate attention between STM layer and combined self/interlayer state
            self_interlayer_stm = self.mean_attention_layers[i](pre_normalized_layer_stm, self_interlayer_stm_input, self_interlayer_stm_input, mask=None)
            # d) combine updated interlayer state with current STM state in residual gate
            self_interlayer_query = self.mean_residual_gate_layers[i](layer_stm, self_interlayer_stm)

            # 8. Main memory attention
            new_stm[i] = self._main_attention(i, self_interlayer_query, keys, values, layer_stm, mask=attention_mask)
        # 9. Update all layers/models
        self.stm.update_all(new_stm)
        return self.stm.memory


class RcGroupedStmMemoryAttention(RcGatedStmMemoryAttention):
    def __init__(
            self,
            num_groups: int,
            *args,
            **kwargs
    ):
        super(RcGroupedStmMemoryAttention, self).__init__(*args, **kwargs)
        self.num_groups = num_groups
        self.layers_per_group = self.num_layers // self.num_groups

    def forward(self, keys: list[torch.Tensor], values: list[torch.Tensor],
                attention_mask: torch.Tensor = None) -> torch.Tensor:
        # 2. Init new empty STM
        new_stm = torch.zeros_like(self.stm.memory)

        # 3. Get memory groups
        stm_groups = torch.stack(self.stm.memory.chunk(self.num_groups, dim=0))

        # 4. Get mean STM value for layer groups
        stm_group_means = stm_groups.mean(dim=1) # [num_groups, batch_size, stm_size, embed_dim]
        # 5. Normalize mean STM layer
        normalized_stm_groups = self.mean_stm_norm(stm_group_means)

        # 5. Run Short-Term Memory update for all layers
        group_idx = 0
        for i in range(self.num_layers):
            if i % self.layers_per_group == 0 and i != 0:
                group_idx += 1
            # 6. Get current layer STM value
            layer_stm = self.stm(i)

            # 7. Gated self/interlayer memory attention
            # a) normalize STM layer value
            pre_normalized_layer_stm = self.mean_memory_norm_layers[i](layer_stm)
            # b) combine interlayer and current layer data with gate
            self_interlayer_stm_input = self.interlayer_gate_layers[i](pre_normalized_layer_stm, normalized_stm_groups[group_idx])
            # c) calculate attention between STM layer and combined self/interlayer state
            self_interlayer_stm = self.mean_attention_layers[i](pre_normalized_layer_stm, self_interlayer_stm_input,
                                                                self_interlayer_stm_input, mask=None)
            # d) combine updated interlayer state with current STM state in residual gate
            self_interlayer_query = self.mean_residual_gate_layers[i](layer_stm, self_interlayer_stm)

            # 8. Main memory attention
            new_stm[i] = self._main_attention(i, self_interlayer_query, keys, values, layer_stm, mask=attention_mask)
        # 9. Update all layers/models
        self.stm.update_all(new_stm)
        return self.stm.memory


class RcSimpleStmMemoryAttention(nn.Module):
    def __init__(
            self,
            stm: ShortTermMemory,
            attention_layers: nn.ModuleList,
            memory_norm_layers: nn.ModuleList,
            memory_input_norm_layers: nn.ModuleList,
            residual_gate_layers: nn.ModuleList,
            **kwargs
    ):
        super(RcSimpleStmMemoryAttention, self).__init__(**kwargs)

        self.stm = stm
        self.attention_layers = attention_layers
        self.num_layers = len(attention_layers)
        self.memory_norm_layers = memory_norm_layers
        self.memory_input_norm_layers = memory_input_norm_layers
        self.residual_gate_layers = residual_gate_layers
        assert (len(self.attention_layers) == len(self.memory_norm_layers) ==
                len(self.residual_gate_layers) == len(self.memory_input_norm_layers) ==
                self.stm.memory.size(0))


    def update_max_len(self, max_seq_len: int):
        for i in range(self.num_layers):
            if self.attention_layers[i].rope is not None:
                self.attention_layers[i].rope.update_max_len(max_seq_len)

    def _main_attention(
            self,
            layer_idx: int,
            layer_stm: torch.Tensor,
            keys: list[torch.Tensor],
            values: list[torch.Tensor],
            mask: torch.Tensor = None
    ) -> torch.Tensor:
        layer_keys = keys[layer_idx]
        layer_values = values[layer_idx]

        b, h, t, d  = layer_keys.size()

        layer_keys = layer_keys.transpose(1, 2).reshape(b, t, h * d)
        layer_values = layer_values.transpose(1, 2).reshape(b, t, h * d)

        # 1. Normalize encoded layer data
        norm_keys = self.memory_input_norm_layers[layer_idx](layer_keys)
        norm_values = self.memory_input_norm_layers[layer_idx](layer_values)
        # 2. Normalize STM layer
        normalized_layer_stm = self.memory_norm_layers[layer_idx](layer_stm)

        # 3. Calculate memory attention
        new_layer_stm = self.attention_layers[layer_idx](
            normalized_layer_stm,
            norm_keys,
            norm_values,
            mask=mask.unsqueeze(1).unsqueeze(1).bool() if mask is not None else None,
        )
        # 4. Combine new updated layer state with current STM state in residual gate
        return self.residual_gate_layers[layer_idx](layer_stm, new_layer_stm)  # residual

    def forward(self, keys: list[torch.Tensor], values: list[torch.Tensor], attention_mask: torch.Tensor = None) -> torch.Tensor:
        # 1. Init new empty STM
        new_stm = torch.zeros_like(self.stm.memory)

        # 2. Run Short-Term Memory update for all layers
        for i in range(self.num_layers):
            # 3. Get current layer STM value
            layer_stm = self.stm(i)

            # 4. Main memory attention
            new_stm[i] = self._main_attention(i, layer_stm, keys, values, mask=attention_mask)
        # 5. Update all layers/models
        self.stm.update_all(new_stm)
        return self.stm.memory


class RcSelfStmMemoryAttention(nn.Module):
    def __init__(
            self,
            stm: ShortTermMemory,
            attention_layers: nn.ModuleList,
            memory_norm_layers: nn.ModuleList,
            memory_input_norm_layers: nn.ModuleList,
            residual_gate_layers: nn.ModuleList,
            self_attention_layers: nn.ModuleList,
            self_memory_norm_layers: nn.ModuleList,
            self_residual_gate_layers: nn.ModuleList,
            **kwargs
    ):
        super(RcSelfStmMemoryAttention, self).__init__(**kwargs)

        self.stm = stm
        self.attention_layers = attention_layers
        self.num_layers = len(attention_layers)
        self.memory_norm_layers = memory_norm_layers
        self.memory_input_norm_layers = memory_input_norm_layers
        self.residual_gate_layers = residual_gate_layers
        assert (len(self.attention_layers) == len(self.memory_norm_layers) ==
                len(self.residual_gate_layers) == len(self.memory_input_norm_layers) ==
                self.stm.memory.size(0))

        self.self_attention_layers = self_attention_layers
        self.self_memory_norm_layers = self_memory_norm_layers
        self.self_residual_gate_layers = self_residual_gate_layers

        assert (len(self.self_attention_layers) == len(self.self_memory_norm_layers) ==
                len(self.self_residual_gate_layers) == self.num_layers)

    def update_max_len(self, max_seq_len: int):
        for i in range(self.num_layers):
            if self.attention_layers[i].rope is not None:
                self.attention_layers[i].rope.update_max_len(max_seq_len)

    def _main_attention(
            self,
            layer_idx: int,
            layer_stm: torch.Tensor,
            keys: list[torch.Tensor],
            values: list[torch.Tensor],
            past_layer_stm: torch.Tensor,
            mask: torch.Tensor = None
    ) -> torch.Tensor:
        layer_keys = keys[layer_idx]
        layer_values = values[layer_idx]

        b, h, t, d  = layer_keys.size()

        layer_keys = layer_keys.transpose(1, 2).reshape(b, t, h * d)
        layer_values = layer_values.transpose(1, 2).reshape(b, t, h * d)

        # 1. Normalize encoded layer data
        norm_keys = self.memory_input_norm_layers[layer_idx](layer_keys)
        norm_values = self.memory_input_norm_layers[layer_idx](layer_values)
        # 2. Normalize STM layer
        normalized_layer_stm = self.memory_norm_layers[layer_idx](layer_stm)

        # 3. Calculate memory attention
        new_layer_stm = self.attention_layers[layer_idx](
            normalized_layer_stm,
            norm_keys,
            norm_values,
            mask=mask.unsqueeze(1).unsqueeze(1).bool() if mask is not None else None,
        )
        # 4. Combine new updated layer state with current STM state in residual gate
        return self.residual_gate_layers[layer_idx](past_layer_stm, new_layer_stm)  # residual

    def forward(self, keys: list[torch.Tensor], values: list[torch.Tensor], attention_mask: torch.Tensor = None) -> torch.Tensor:
        # 1. Init new empty STM
        new_stm = torch.zeros_like(self.stm.memory)

        # 5. Run Short-Term Memory update for all layers
        for i in range(self.num_layers):
            # 6. Get current layer STM value
            layer_stm = self.stm(i)

            # 7. Gated self/interlayer memory attention
            # a) normalize STM layer value
            pre_normalized_layer_stm = self.self_memory_norm_layers[i](layer_stm)

            # c) calculate attention between STM layer and combined self/interlayer state
            self_interlayer_stm = self.self_attention_layers[i](pre_normalized_layer_stm, pre_normalized_layer_stm, pre_normalized_layer_stm, mask=None)
            # d) combine updated interlayer state with current STM state in residual gate
            updated_layer_stm = self.self_residual_gate_layers[i](layer_stm, self_interlayer_stm)

            # 8. Main memory attention
            new_stm[i] = self._main_attention(i, updated_layer_stm, keys, values, layer_stm, mask=attention_mask)
        # 9. Update all layers/models
        self.stm.update_all(new_stm)
        return self.stm.memory